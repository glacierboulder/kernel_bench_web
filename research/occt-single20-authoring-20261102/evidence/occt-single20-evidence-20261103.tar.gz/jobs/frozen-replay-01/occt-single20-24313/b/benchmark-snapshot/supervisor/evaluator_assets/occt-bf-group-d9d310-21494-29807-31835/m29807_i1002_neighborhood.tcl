puts "========"
puts "0029807: Impossible to cut cone from prism"
puts "========"
puts ""

restore [locate_data_file bug29807-obj.brep] b1
restore [locate_data_file bug29807-tool.brep] b2

trotate b2 +23.85857157145715500000 +12.00000000000000000000 +5.50000000000000000000 7 -7.14142842854285 0 5
removeloc b2 b2

explode b1 f
explode b2 f
smallview
don b1_5 b2_2
fit

regexp {Tolerance Reached=+([-0-9.+eE]+)\n+([-0-9.+eE]+)} [bopcurves b1_5 b2_2 -2d] full Toler NbCurv

checkreal Tolerance $Toler 0.00039718358540697849 0.0 0.01

if {$NbCurv != 2} {
  puts "Error: Please check NbCurves for intersector"
}

checkview -screenshot -2d -path ${imagedir}/${test_image}_3d.png
smallview -2D-
2dfit
checkview -screenshot -2d -path ${imagedir}/${test_image}_2d.png
