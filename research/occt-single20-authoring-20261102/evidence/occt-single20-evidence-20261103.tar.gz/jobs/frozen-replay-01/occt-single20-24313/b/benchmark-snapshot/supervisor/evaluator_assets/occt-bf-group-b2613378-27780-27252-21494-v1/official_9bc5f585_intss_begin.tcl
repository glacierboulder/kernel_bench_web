# Checks whether theCurve has a loop/bend
# Use: CheckLoops curve CosMaxAngle [theNbPoints]}
# theNbPoints sets the interval of discretization;
# theCosMaxAngle sets the maximal rotation angle between two adjacent segments. This value must be equal to the cosine of this angle.

help CheckLoops {curve CosMaxAngle theNbPoints }
proc CheckLoops {theCurve theCosMaxAngle {theNbPoints 1000.0}} {
  upvar #0 $theCurve aCurve
  bounds aCurve U1 U2
    
  set delta [dval (U2-U1)/$theNbPoints]
  cvalue aCurve [dval U1] xp yp zp dx1 dy1 dz1
  
  for {set p [dval U1]} {$p <= [dval U2]} {set p [expr $p + $delta]} {
    cvalue aCurve $p xp yp zp dx2 dy2 dz2
    
    #Check if the angle between the vectors {dx1 dy1 dz1} and {dx2 dy2 dz2} is less than 30deg.
    set nv1 [ dval dx1*dx1+dy1*dy1+dz1*dz1 ] 
    set nv2 [ dval dx2*dx2+dy2*dy2+dz2*dz2 ] 
    set dp [ dval dx1*dx2+dy2*dy2+dz1*dz2 ] 
    
    if {$dp < [ expr $theCosMaxAngle * sqrt($nv1 * $nv2) ] } {
      puts "Error: The curve aCurve is possible to have a bend at parameter $p. Please check carefully"
    }      
    
    dset dx1 dx2
    dset dy1 dy2
    dset dz1 dz2
  }
}

# General check of the result of geometrical intersection
help CheckIntersectionResult { surf1 surf2 ListOfCurves NbPoints TolerS1 TolerS2 }
proc CheckIntersectionResult {theSurf1 theSurf2 theListOfCurves theNbPoints theTolerS1 theTolerS2} {
  upvar #0 $theSurf1 s1
  upvar #0 $theSurf2 s2

  foreach a $theListOfCurves {
    puts "** Check of $a **"
    upvar #0 $a aCurve
    bounds aCurve U1 U2
    
    if {[dval U2-U1] < 1.0e-9} {
      puts "Error: Wrong range of $a"
    }
    
    xdistcs aCurve s1 U1 U2 $theNbPoints $theTolerS1
    xdistcs aCurve s2 U1 U2 $theNbPoints $theTolerS2
  }
}