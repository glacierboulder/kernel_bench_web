pload TOPTEST
ptorus b1 25 24 90
plane p 20 20 10 0 0 1
pcone b2 p 10 8 40
explode b1 f
copy b1_1 b1
explode b2 f
copy b2_1 b2
mksurface s1 b1
mksurface s2 b2
trimu s1t s1 0 1.5707963267948966
trimv s2t s2 0 40.049968789001575
intersect ii s1t s2t
bounds ii_1 u1 u2
xdistcs ii_1 s1 u1 u2 10 2e-7
xdistcs ii_1 s2 u1 u2 10 2e-7
