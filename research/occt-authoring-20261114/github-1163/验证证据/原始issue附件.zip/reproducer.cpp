// Standalone reproducer for OCCT crash in ChFi3d_Builder::IntersectMoreCorner
//
// BRepFilletAPI_MakeChamfer segfaults when applied to shapes that have gone
// through prior boolean/chamfer operations due to stale TShape pointers in
// internal topology maps.  BRepBuilderAPI_Copy workaround breaks the sharing
// and avoids the crash.
//
// Build:  cmake -B build && cmake --build build
// Run:    ./build/reproducer <path-to-chamfer007.brep>
//
// Expected: "WITHOUT copy" crashes (segfault); "WITH copy" succeeds.

#include <BRep_Builder.hxx>
#include <BRepBuilderAPI_Copy.hxx>
#include <BRepFilletAPI_MakeChamfer.hxx>
#include <BRepTools.hxx>
#include <TopAbs_ShapeEnum.hxx>
#include <TopExp.hxx>
#include <TopExp_Explorer.hxx>
#include <TopTools_IndexedDataMapOfShapeListOfShape.hxx>
#include <TopTools_IndexedMapOfShape.hxx>
#include <TopTools_ListOfShape.hxx>
#include <TopoDS.hxx>
#include <TopoDS_Edge.hxx>
#include <TopoDS_Face.hxx>
#include <TopoDS_Shape.hxx>
#include <Standard_Failure.hxx>

#include <iostream>
#include <string>
#include <cstdlib>

#ifndef _WIN32
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#endif

// Try to chamfer edge at 0-based index |edgeIndex| of |shape| with the given
// distance.  Returns true on success, false on OCCT exception, and crashes
// (segfault) when the bug is triggered.
static bool tryChamfer(const TopoDS_Shape& shape,
                       int                 edgeIndex,
                       double              dist,
                       const char*         label)
{
    TopTools_IndexedMapOfShape edgeMap;
    TopExp::MapShapes(shape, TopAbs_EDGE, edgeMap);

    if (edgeIndex < 0 || edgeIndex >= edgeMap.Extent()) {
        std::cerr << label << ": edge index " << edgeIndex
                  << " out of range (0.." << edgeMap.Extent() - 1 << ")\n";
        return false;
    }

    const TopoDS_Edge& edge = TopoDS::Edge(edgeMap(edgeIndex + 1));  // 1-based

    try {
        BRepFilletAPI_MakeChamfer chamfer(shape);
        // Find a face adjacent to the edge for the Add() call.
        TopTools_IndexedDataMapOfShapeListOfShape edgeFaceMap;
        TopExp::MapShapesAndAncestors(shape, TopAbs_EDGE, TopAbs_FACE, edgeFaceMap);
        const TopTools_ListOfShape& faces = edgeFaceMap.FindFromKey(edge);
        if (faces.IsEmpty()) {
            std::cerr << label << ": no adjacent face for edge " << edgeIndex << "\n";
            return false;
        }
        const TopoDS_Face& face = TopoDS::Face(faces.First());
        chamfer.Add(dist, dist, edge, face);
        chamfer.Build();
        if (!chamfer.IsDone()) {
            std::cerr << label << ": MakeChamfer.Build() failed (IsDone=false)\n";
            return false;
        }
        const TopoDS_Shape& result = chamfer.Shape();
        if (result.IsNull()) {
            std::cerr << label << ": result shape is null\n";
            return false;
        }
        std::cout << label << ": SUCCESS\n";
        return true;
    }
    catch (const Standard_Failure& e) {
        std::cerr << label << ": OCCT exception: " << e.GetMessageString() << "\n";
        return false;
    }
}

int main(int argc, char* argv[])
{
    if (argc < 2) {
        std::cerr << "Usage: " << argv[0] << " <chamfer007.brep>\n";
        return 1;
    }
    const char* brepPath = argv[1];

    // ---- Read the .brep file ------------------------------------------------
    BRep_Builder builder;
    TopoDS_Shape originalShape;
    if (!BRepTools::Read(originalShape, brepPath, builder)) {
        std::cerr << "Failed to read BREP file: " << brepPath << "\n";
        return 1;
    }
    std::cout << "Loaded shape from " << brepPath << "\n";

    TopTools_IndexedMapOfShape edges;
    TopExp::MapShapes(originalShape, TopAbs_EDGE, edges);
    std::cout << "Shape has " << edges.Extent() << " edges\n";

    const int    targetEdge  = 6;   // 0-based; edge 7 in the FreeCAD test
    const double chamferDist = 1.0;

    // ---- Test 1: WITHOUT BRepBuilderAPI_Copy (crashes) ----------------------
    std::cout << "\n--- Test 1: chamfer WITHOUT BRepBuilderAPI_Copy ---\n";
    std::cout << "(This is expected to CRASH with a segfault in\n"
              << " ChFi3d_Builder::IntersectMoreCorner due to null Arcprolbis)\n\n";

    // Fork so the crash doesn't kill our reporting process.
    // On systems without fork(), just call tryChamfer directly and accept the crash.
#ifdef _WIN32
    std::cout << "Skipping crash test on Windows (no fork). "
              << "Run manually to observe the segfault.\n";
#else
    {
        pid_t pid = fork();
        if (pid == 0) {
            // Child: will crash
            tryChamfer(originalShape, targetEdge, chamferDist, "WITHOUT copy");
            _exit(0);  // should not reach here
        } else if (pid > 0) {
            int status = 0;
            waitpid(pid, &status, 0);
            if (WIFSIGNALED(status)) {
                std::cout << "Child crashed with signal " << WTERMSIG(status)
                          << " (expected: 11 = SIGSEGV)\n";
            } else {
                std::cout << "Child exited with status " << WEXITSTATUS(status) << "\n";
            }
        } else {
            // fork failed, try directly
            tryChamfer(originalShape, targetEdge, chamferDist, "WITHOUT copy");
        }
    }
#endif

    // ---- Test 2: WITH BRepBuilderAPI_Copy (workaround) ----------------------
    std::cout << "\n--- Test 2: chamfer WITH BRepBuilderAPI_Copy ---\n";
    {
        BRepBuilderAPI_Copy copier(originalShape);
        TopoDS_Shape copiedShape = copier.Shape();
        tryChamfer(copiedShape, targetEdge, chamferDist, "WITH copy");
    }

    std::cout << "\nDone.\n";
    return 0;
}
