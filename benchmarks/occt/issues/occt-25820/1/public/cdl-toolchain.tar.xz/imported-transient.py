"""Bridge WOK 6.3's imported-value spelling to the later imported handle declaration."""
from pathlib import Path
import re
import sys

phase, path = sys.argv[1:]
root = Path(path)
if phase == "declarations":
    for package, name in [("BSplCLib", "Cache"), ("BSplSLib", "Cache"), ("BRepBuilderAPI", "FastSewing")]:
        cdl = root / "cdlin" / (package + ".cdl")
        original = cdl.read_text()
        marker = "imported transient class " + name + ";"
        assert original.count(marker) == 1
        assert cdl.is_symlink()
        cdl.unlink()
        cdl.write_text(original.replace(marker, "imported " + name + ";"))
elif phase == "fields":
    for owner, typ, field in [("Geom2dAdaptor_Curve", "BSplCLib_Cache", "myCurveCache"),
                             ("GeomAdaptor_Curve", "BSplCLib_Cache", "myCurveCache"),
                             ("GeomAdaptor_Surface", "BSplSLib_Cache", "mySurfaceCache")]:
        header = root / "gen" / (owner + ".hxx")
        pattern = r"\b" + typ + r"\s+" + field + r"\s*;"
        text, count = re.subn(pattern, "Handle(" + typ + ") " + field + ";", header.read_text())
        assert count == 1, (header,field)
        header.write_text(text)
