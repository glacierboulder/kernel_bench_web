"""Rename the old private helper after libc's distinct fsqrt declaration is visible."""
from pathlib import Path
import re
import sys

root=Path(sys.argv[1])
header=root/"glibc-fsqrt.hxx"
header.write_text("#include <cmath>\n#define fsqrt occt_local_fsqrt\n")
manifest=root/"build.ninja"
text=manifest.read_text()
pattern=r"(?m)^(build obj/BOPTools_AlgoTools\.cxx\.o:[^\n]*)(\n  cflags = [^\n]*)?"
def insert(m):
    tail=m[2] or "\n  cflags = $cflags"
    return m[1]+tail+" -include "+str(header)
if str(header) not in text:
    text,count=re.subn(pattern,insert,text)
    assert count==1
    manifest.write_text(text)
