from pathlib import Path
import os,sys
from queue import SimpleQueue
from concurrent.futures import ThreadPoolExecutor
from evaluate import ROOT,verify,runtimes,sha
helper=Path('/home/lzy/cad-bench-experiment/common-empirical-third-20261120/registered.py')
assert sha(helper)=='83fc258535b44bd4cd2a47ee53b064d92e6b22b5a4edf7c42e9bdfba4a8e01b9'
sys.path.insert(0,str(helper.parent))
import registered as bench
snap=ROOT/'final/benchmark-snapshot'
bench.verify_snapshot(snap)
def native(role):
    verify(role);rt=runtimes[role]
    w=ROOT/'registered'/role;w.mkdir(parents=True)
    mounts=[(snap/'supervisor','/control',False),(snap/'suite.json','/suite.json',False),(ROOT/'dispatch.py','/dispatch.py',False),
            (rt/'source','/occt-source',False),(rt/'build','/occt-build',False)]
    code=bench.invoke(w,[sys.executable,'/dispatch.py'],w/'dispatch.log',850,mounts,extra={'CASROOT':'/occt-source','BENCH_FROZEN_CASE_ROOT':'/control/cases/bundle'})
    print(role,code,flush=True);assert code==0,(role,(w/'dispatch.log').read_text()[-1200:])
cpus=sorted(os.sched_getaffinity(0));lanes=SimpleQueue()
n=min(5,max(1,len(cpus)//2))
for i in range(n):lanes.put(cpus[2*i:2*i+2])
with ThreadPoolExecutor(max_workers=n,initializer=lambda:os.sched_setaffinity(0,lanes.get())) as pool:
    list(pool.map(native,('B','F','round1','round2','round3')))
bench.verify_snapshot(snap)
