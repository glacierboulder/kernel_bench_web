"""Collect original scoring evidence without source or build-tree caches."""
from pathlib import Path
import hashlib,json,tarfile
from backend.freeze import verify_snapshot
root=Path(__file__).resolve().parent
snap=root/'final/benchmark-snapshot'
verify_snapshot(snap)
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
wanted=['protocol.json','axial.json','gate.json','nominees.json','freeze.json','final-material-verification.json','catalog-tests.log',
      'primary.log','reserve.log','alternatives.log','axial.log','confirm.log','controls.log','rescore.log','builds.log','native.log',
      'native-controls.log','dispatch.py','native.py','native_controls.py','build.py','evaluate.py','freeze_study.py','gate.py','verify_final.py','axial_plan.py',
      'archive.py','final/benchmark-snapshot/suite.json','final/benchmark-snapshot/supervisor/evaluator_assets/unified_runtime/contract.json']
for folder in ('assets','patches','tools'):
    wanted += [str(p.relative_to(root)) for p in sorted((root/folder).glob('*')) if p.is_file() and not p.name.startswith('._')]
for p in sorted((root/'jobs').glob('*/*/*/score.json')):
    wanted += [str((p.parent/n).relative_to(root)) for n in ('score.json','produce.log','draw.log','first.log','second.log','result.log','first.brep','second.brep','result.brep')]
for label in ('B','F','round1','round2','round3'):
    folder=root/'registered'/label
    suite=json.loads((snap/'suite.json').read_bytes())
    wanted += [str((folder/(c['id']+'.json')).relative_to(root)) for c in suite['checkpoints']]
    wanted.append(str((folder/'dispatch.log').relative_to(root)))
    if label.startswith('round'):
        wanted += [f'builds/{label}/{n}' for n in ('binaries.json','receipt.json','build.log')]
for p in sorted((root/'registered-controls').glob('*/*/receipt.json')):
    wanted += [str(p.relative_to(root)),str(p.with_name('draw.log').relative_to(root))]
assert len(set(wanted))==len(wanted)
manifest={n:sha(root/n) for n in wanted}
(root/'evidence-files.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(root/'evidence.tar.gz','w:gz') as t:
    for n in wanted+['evidence-files.json']:
        t.add(root/n,arcname=n,recursive=False)
print(len(wanted),'files',sha(root/'evidence.tar.gz'),flush=True)
