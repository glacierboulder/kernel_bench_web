"""Reapply each frozen 10-minute submission to a distinct verified baseline."""
import hashlib,json,sys
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
from evaluate import ROOT, spec, runtimes, sha, verify, write
helper=Path('/home/lzy/cad-bench-experiment/common-empirical-third-20261120/registered.py')
assert sha(helper)=='83fc258535b44bd4cd2a47ee53b064d92e6b22b5a4edf7c42e9bdfba4a8e01b9'
sys.path.insert(0,str(helper.parent))
import registered as bench
base=runtimes['B']
verify('B')
frozen=base.parent/'benchmark-snapshot'
bench.verify_snapshot(frozen)
tools=frozen/'tools'
assert sha(tools/'build.sh')=='120226564a3a284562b373d2ac97cbd55f87b6a48aa401755b705f9c13f82068'
def build(role):
    rt=runtimes[role];rt.mkdir(parents=True)
    for k in ('source','build'):bench.copy(base/k,rt/k)
    assert bench.tree_sha256(rt/'source')==spec['origins']['B']['source_tree']
    patch=ROOT/'patches'/(role+'.diff')
    assert sha(patch)==spec['rounds'][role]['sha256']
    bench.apply_patch(rt/'source',str(patch))
    code=bench.invoke(rt,['bash','/tools/build.sh','/workspace/source','/workspace/build'],rt.parent/'build.log',1800,[(tools,'/tools',False)])
    assert code==0,role
    old=spec['origins']['B']['binaries']
    digests={p:sha(rt/'build'/p) for p in old}
    changed=[p for p in digests if digests[p]!=old[p]]
    assert any('/lib/' in p for p in changed),changed
    write(rt.parent/'binaries.json',digests)
    write(rt.parent/'receipt.json',dict(base=spec['baseline'],source_tree=bench.tree_sha256(rt/'source'),patch=sha(patch),build_exit=code,changed=changed))
    print(role,'built',changed,flush=True)
with ThreadPoolExecutor(max_workers=1) as pool:list(pool.map(build,spec['rounds']))
