"""A finite, reference-only fallback for truncation at the bottom or top cylinder plane."""
from pathlib import Path
import sys, math, json, hashlib
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'tools'))
import analytic as a
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def properties(h,n):
    t0=max(0.,-h);t1=min(a.H,a.H-h)
    hi=a.B*(1-t0/a.H);lo=a.B*(1-t1/a.H)
    d=math.hypot(a.X,a.Y)
    def ang(r):return math.acos(max(-1.,min(1.,(r*r+(d-a.R)*(d+a.R))/(2*d*r))))
    def rings(r):return a.integrate(lambda q:2*q*ang(q),0,r,n)
    def bow(r):return 2*math.asin(math.sqrt(max(0,(r*r-(d-a.R)**2)/(4*a.R*d))))
    bottom=a.lens(hi,d);top=a.lens(lo,d)
    width=math.hypot(a.B,a.H)/a.B
    vol=a.integrate(lambda r:a.lens(r,d)*a.H/a.B,lo,hi,n)
    vol2=rings(lo)*(t1-t0)+a.integrate(lambda r:2*r*ang(r)*(a.H*(1-r/a.B)-t0),lo,hi,n)
    side=a.integrate(lambda r:2*r*a.angles(r,d)[0]*width+2*a.R*a.angles(r,d)[1]*a.H/a.B,lo,hi,n)
    stripe=2*a.R*(bow(lo)*(t1-t0)+a.integrate(lambda t:a.H*(1-math.hypot(d-a.R,2*math.sqrt(a.R*d)*math.sin(t/2))/a.B)-t0,bow(lo),bow(hi),n))
    ar2=rings(hi)+rings(lo)+(rings(hi)-rings(lo))*width+stripe
    return dict(volume=vol,area=bottom+top+side,polar_volume=vol2,strip_area=ar2)
def witnesses(h):
    d=math.hypot(a.X,a.Y);u=a.X/d;v=a.Y/d
    low=max(0.,h);high=min(a.H,h+a.H)
    zvals=[low+(high-low)*f for f in (.02,.23,.51,.79,.98)]+[low-0.75,high+0.75]
    out=[]
    for z in zvals:
        r=a.B*max(.01,min(1.,1-(z-h)/a.H))
        for p in (-1.21,-.83,-.45,-.13,.13,.45,.83,1.21):
            for q in (-.77,-.22,.22,.77):
                x=d+p*r; y=q*r
                m1=a.R-math.hypot(x,y); m2=(a.B*(1-(z-h)/a.H)-math.hypot(x-d,y))/math.hypot(1,a.B/a.H)
                if min(map(abs,(m1,m2,z,z-a.H,z-h,z-h-a.H)))<.06:continue
                first=m1>0 and 0<z<a.H;second=m2>0 and h<z<h+a.H
                out.append(((x*u-y*v,x*v+y*u,z),first,second))
    return out
from rigid import rotated
def main():
    s=json.loads((root/'protocol.json').read_bytes())
    assert max(abs(properties(0.,8192)[k]-v) for k,v in s['gold']['fine'].items())<1e-6
    result={}
    for f in (1/64,1/8,1/2,3/4):
        for sign,key,pose in ((-1,'down','axis31'),(1,'up','z90')):
            h=sign*a.H*f;label=f'{key}-{abs(h):g}';params=s['poses'][pose]
            fine=properties(h,8192);coarse=properties(h,2048)
            assert max(abs(v-coarse[k]) for k,v in fine.items())<1e-6
            assert abs(fine['volume']-fine['polar_volume'])<1e-7 and abs(fine['area']-fine['strip_area'])<1e-7
            points=witnesses(h); inside=sum(a and b for _,a,b in points)
            assert 15<inside<len(points)-15
            files={}
            for shape in ('first','second','result'):
                dest=root/'assets'/f'{label}-{shape}.pts'
                with dest.open('w') as out:
                    for coords,first,second in points:
                        wanted={'first':first,'second':second,'result':first and second}[shape]
                        print(*[format(x,'.17g') for x in rotated(coords,params)],int(wanted),file=out)
                files[dest.name]=sha(dest)
            dest=root/'assets'/f'{label}.pose';dest.write_text(' '.join(map(str,params))+'\n');files[dest.name]=sha(dest)
            result[label]=dict(height=h,rotation=pose,fine=fine,coarse=coarse,inside=inside,outside=len(points)-inside,assets_sha256=files)
    (root/'axial.json').write_text(json.dumps(dict(reason='No natural positive and no baseline-healthy rotation among the six registered rigid probes.',
        order=list(result),gate='Screen B and locked F. Select earliest stable failing/healthy case in declared order, preferring locked F; alternative natural references only if necessary. Confirm selected pair twice. Three known incorrect shapes must fail independently for each, including shifted correct output.',
        protocol_sha256=sha(root/'protocol.json'),cases=result),indent=2)+'\n')
if __name__=='__main__':main()
