"""Generate posed originals in a locked kernel; read serialized results in a single fixed kernel."""
from concurrent.futures import ThreadPoolExecutor
import hashlib, itertools, json, os, re, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parent
def load(p):return json.loads(p.read_bytes())
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,v):p.write_text(json.dumps(v,indent=2,allow_nan=False)+'\n')
spec=load(ROOT/'protocol.json')
old=Path('/var/tmp/m25542-positive-reference-20261119')
assert sha(old/'runner.py')==spec['prior_reader_helper_sha256']
sys.path.insert(0,str(old))
import runner
sys.path.insert(0,str(ROOT/'tools'))
from criteria import measure
runtimes={k:Path(v['runtime']) for k,v in {**spec['origins'],**spec['alternative_references']}.items()}
runtimes.update({k:ROOT/'builds'/k/'clean' for k in spec['rounds']})
def verify(label):
    rt=runtimes[label]
    if label in spec['origins']:
        orig=spec['origins'][label]
        assert runner.tree_sha256(rt/'source')==orig['source_tree']
        assert sha(rt.parent/'runtime-binaries.json')==orig['manifest_sha256']
        for key,h in orig['binaries'].items():assert sha(rt/'build'/key)==h
    elif label in spec['alternative_references']:
        orig=spec['alternative_references'][label]
        assert runner.tree_sha256(rt/'source')==orig['tree']
        layout,_=runner.layout(rt)
        for k,h in orig['binaries'].items():assert sha(rt/'build'/layout/('bin' if k=='DRAWEXE' else 'lib')/k)==h
    else:
        receipt=load(rt.parent/'receipt.json')
        assert receipt['patch']==spec['rounds'][label]['sha256'] and receipt['build_exit']==0
        assert runner.tree_sha256(rt/'source')==receipt['source_tree']
        for k,h in load(rt.parent/'binaries.json').items():assert sha(rt/'build'/k)==h
axial=load(ROOT/'axial.json')['cases'] if (ROOT/'axial.json').is_file() else {}
def execute(job):
    label,pose,rep=job
    folder=ROOT/'jobs'/label/pose/str(rep)
    folder.mkdir(parents=True)
    control=label in ('gold','shifted','empty','cone')
    rt=runtimes['F' if control else label]
    mounts=[(ROOT/'assets','/qualified/assets',False),(ROOT/'tools','/qualified/tools',False)]
    g=axial.get(pose,spec['gold'])
    height=g.get('height',0)
    target=g['fine']['area'] if height else spec['draw_area_reference']
    total=g['inside']+g['outside']
    if height:
        for k,v in g['assets_sha256'].items():assert sha(ROOT/'assets'/k)==v
    if height and label in ('gold','shifted'):
        ref=load(ROOT/'nominees.json')[pose]['reference']
        positive=ROOT/'jobs'/ref/pose/'1/result.brep'
        assert sha(positive)==load(positive.parent/'score.json')['sha256']
        mounts.append((positive,'/positive.brep',False))
    runner.invoke(rt,folder,['@DRAW@','-b','-f','/qualified/tools/produce.tcl'],folder/'produce.log',
                  dict(POSE=pose,MODE=label if control else 'candidate',AXIAL=str(height)),mounts)
    prod=(folder/'produce.log').read_text()
    assert 'GENERATION_COMPLETE' in prod.splitlines(),prod[-800:]
    if not control: assert re.search('^COMMON ',prod,re.M) and re.search('^FILL ',prod,re.M)
    reader=runtimes['F']
    runner.invoke(reader,folder,['@DRAW@','-b','-f','/qualified/tools/read_draw.tcl'],folder/'draw.log',dict(EXPECT_AREA=str(target)),mounts=mounts+[(folder,'/art',False)])
    draw=(folder/'draw.log').read_text()
    events=re.findall(r'^BENCH_ASSERT_(PASS|FAIL) (\w+)',draw,re.M)
    assert [i for _,i in events]==['input_validity','validity','component_count','measure','centroid_domain'] and 'TEST_DONE assertions=5 numeric_assertions=3' in draw,draw[-1000:]
    for name in ('first','second','result'):
        runner.invoke(reader,folder,['/old-bin/F-observer','/shape','/points'],folder/(name+'.log'),
             mounts=[(folder/(name+'.brep'),'/shape',False),(ROOT/'assets'/(pose+'-'+name+'.pts'),'/points',False)])
    for n in ('first','second'):
        log=(folder/(n+'.log')).read_text().splitlines()
        valid,count,shells,faces,closed=map(int,next(s.split()[1:] for s in log if s.startswith('SHAPE ')))
        assert (valid,count,closed)==(1,1,1) and shells>=1 and f'POINTS {total} 0 0' in log,(label,pose,n,log[-2:])
    result=measure(folder/'result.log',g,spec['criteria'])
    failed=[name for status,name in events if status=='FAIL']
    assert 'input_validity' not in failed
    status='FAIL' if failed else result['status']
    row=dict(label=label,pose=pose,repeat=rep,status=status,failed_draw=failed,geometry=result,sha256=sha(folder/'result.brep'))
    write(folder/'score.json',row)
    print(label,pose,rep,status,result['error'],flush=True)
    return row
def run(jobs):
    jobs=list(jobs)
    for name in {j[0] for j in jobs} - {'gold','empty','shifted','cone'}:verify(name)
    verify('F')
    assert sha(Path('/var/tmp/m25542-radial-audit-20261119/bin/F-observer'))==spec['observer_sha256']
    for k,v in spec['source_files'].items():assert sha(ROOT/'assets'/k)==v
    with ThreadPoolExecutor(max_workers=4) as pool:return list(pool.map(execute,jobs))
if __name__=='__main__':
    labs,poses,n=sys.argv[1:]
    selected=labs.split(',')
    if set(selected)&set(spec['rounds']):
        gate=load(ROOT/'gate.json')
        assert set(poses.split(','))<=set(gate['qualified'])
    run(itertools.product(selected,poses.split(','),[int(n)]))
