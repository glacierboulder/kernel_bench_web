"""Select on B/F only, then freeze after a second process and targeted wrong-geometry checks."""
from evaluate import load, write, sha, ROOT, spec, axial
import sys
def row(role,pose,rep=1):return load(ROOT/'jobs'/role/pose/str(rep)/'score.json')
def main(stage):
    order=load(ROOT/'axial.json')['order']
    assert all(row(r,p)['status']=='FAIL' for r in spec['reference_order'] for p in spec['pose_order'])
    chosen={}
    for category,expected in [('neighborhood','FAIL'),('regression','PASS')]:
        pose=next(p for p in order if row('F',p)['status']=='PASS' and row('B',p)['status']==expected)
        chosen[pose]={'role':category,'reference':'F','baseline_status':expected}
    assert len(chosen)==2
    if stage=='nominate':
        write(ROOT/'nominees.json',chosen)
        print(','.join(chosen))
        return
    assert chosen==load(ROOT/'nominees.json')
    for p,v in chosen.items():
        for role,status in [('B',v['baseline_status']),('F','PASS')]:
            r1,r2=(row(role,p,i) for i in (1,2))
            assert r1['status']==r2['status']==status
            assert r1['geometry']['checks']==r2['geometry']['checks'] and r1['failed_draw']==r2['failed_draw']
            assert r1['sha256']==r2['sha256'],(role,p,'output differed between repeats')
        for mode in ('empty','cone','shifted'):
            r=row(mode,p); assert r['status']=='FAIL' and r['geometry']['status']=='FAIL'
        wrong=row('shifted',p)['geometry']['checks']
        assert wrong['volume']==wrong['area']=='PASS' and wrong['points']=='FAIL'
        assert row('gold',p)['status']=='PASS'
    write(ROOT/'gate.json',dict(qualified=chosen,protocol_sha256=sha(ROOT/'protocol.json'),
          axial_plan_sha256=sha(ROOT/'axial.json'),tool_hashes={p.name:sha(p) for p in (ROOT/'tools').iterdir() if p.is_file() and not p.name.startswith('._')},
          external_draw_relative=1e-4,volume_abs=.03,area_abs=.02))
    print(chosen)
if __name__=='__main__': main(sys.argv[1])
