set ::tcl_library /home/lzy/cad-bench-experiment/runtime/py311/lib/tcl8.6
source [file join $::tcl_library init.tcl]
pload TOPTEST
if {[catch {
    set fd [open /qualified/assets/$::env(POSE).pose r]
    set transform [string trim [read $fd]]
    close $fd
    restore /qualified/assets/bug25542_cylinder.brep first
    restore /qualified/assets/bug25542_cone.brep second
    if {$::env(AXIAL) != 0} {ttranslate second 0 0 $::env(AXIAL)}
    trotate first second {*}$transform
    foreach s {first second} {
        if {[string first "This shape seems to be valid" [checkshape $s]] < 0} {error "invalid input $s"}
        save $s $s.brep
    }
    switch $::env(MODE) {
        candidate {
            puts "FILL [bop first second]"
            puts "COMMON [bopcommon result]"
        }
        gold - shifted {
            if {$::env(AXIAL) == 0} {
                restore /qualified/assets/transport.brep result
                trotate result {*}$transform
            } else {
                restore /positive.brep result
            }
            if {$::env(MODE) eq "shifted"} {ttranslate result 500 500 500}
        }
        empty {compound result}
        cone {copy second result}
        default {error "unknown control"}
    }
    save result result.brep
    puts GENERATION_COMPLETE
} msg]} {puts stderr "GENERATION_ERROR $::errorInfo"}
