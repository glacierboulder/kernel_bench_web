set ::tcl_library /home/lzy/cad-bench-experiment/runtime/py311/lib/tcl8.6
source [file join $::tcl_library init.tcl]
if {[catch {
    set root /suite-cases/evaluation/cases/single20/occt-25542/2
    source [file join $root axial_common.tcl]
    # Replay a known serialized shape in the registered observer; producer is exercised separately.
    proc measure_control {pose dz rotation volume area count inside} {
        axial_inputs $dz $rotation
        uplevel #0 {restore /control-result.brep result}
        axial_geometry $pose $volume $area $count $inside
    }
    set f [open [file join $root $::env(CASE_FILE)] r]
    set call [lindex [split [string trim [read $f]] "\n"] end]
    close $f
    if {[lindex $call 0] ne "axial_run"} {error "unexpected case entry"}
    measure_control {*}[lrange $call 1 end]
} msg]} {puts stderr "CONTROL_ERROR $::errorInfo"}
