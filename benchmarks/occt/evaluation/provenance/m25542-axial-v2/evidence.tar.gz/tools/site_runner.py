"""Replay only archived operands on exact builds. All source, build and input mounts are read-only."""
import hashlib,json,os,re,subprocess,sys
from pathlib import Path
from concurrent.futures import ThreadPoolExecutor
S=Path(__file__).resolve().parent
OLD=Path('/var/tmp/m25542-radial-audit-20261119')
BASE=Path('/var/tmp/cad-bench-lzy-single20-20261102')
PY=Path('/home/lzy/cad-bench-experiment/runtime/py311')
os.environ['BENCH_CONFIG']='/home/lzy/cad-bench-experiment/config.json'
sys.path.insert(0,str(BASE/'framework'))
from backend.sandbox import command
from backend.source_cache import tree_sha256
def read(p):return json.loads(p.read_bytes())
def save(p,d):p.write_text(json.dumps(d,indent=2)+'\n')
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
F=BASE/'jobs/frozen-replay-08/occt-single20-25542/f/runtime'
def layout(rt):
    lib=next(x for x in (Path('lin64/clang'),Path('lin64/gcc')) if os.path.lexists(rt/'build'/x/'bin/DRAWEXE'))
    resource='resources' if (rt/'source/resources/DrawResources').is_dir() else 'src'
    return lib,resource
def invoke(rt,work,args,log,extra=None,mounts=()):
    lib,res=layout(rt)
    res='/workspace/source/'+res
    env=dict(CASROOT='/workspace/source',LD_LIBRARY_PATH='/workspace/build/'+str(lib/'lib')+':'+str(PY/'lib'),
             CSF_OCCTResourcePath=res,CSF_PluginDefaults=res+'/StdResource',CSF_DrawPluginDefaults=res+'/DrawResources',
             DRAWHOME=res+'/DrawResources',CSF_LANGUAGE='us')
    env.update(extra or {})
    parts=[(rt/'source','/workspace/source',False),(rt/'build','/workspace/build',False),(OLD/'inputs','/input',False),
           (S/'tools','/study',False),(OLD/'bin','/old-bin',False),(S/'readers','/readers',False),*mounts]
    work.mkdir(parents=True,exist_ok=True)
    if rt==S/'current' or rt in (Path('/var/tmp/cad-boolean-screen30-20261118/baseline'),Path('/var/tmp/cad-bench-m25337-common-20261119/F')):
        img=Path('/var/tmp/cad-boolean-screen30-20261118/image')
        env['LD_LIBRARY_PATH']='/workspace/build/'+str(lib/'lib')
        cmd=['/usr/bin/env','-i','/usr/bin/bwrap','--unshare-all','--die-with-parent','--new-session','--cap-drop','ALL',
             '--tmpfs','/', '--ro-bind',str(img/'usr'),'/usr','--ro-bind',str(img/'bin'),'/bin','--ro-bind',str(img/'lib'),'/lib','--ro-bind',str(img/'lib64'),'/lib64','--ro-bind',str(img/'etc'),'/etc','--proc','/proc','--dev','/dev','--tmpfs','/tmp','--bind',str(work),'/workspace',
             '--ro-bind',str(img/'usr/share/tcltk/tcl8.6'),str(PY/'lib/tcl8.6'),'--chdir','/workspace']
        for path,dest,w in parts:cmd.extend(['--bind' if w else '--ro-bind',str(path.resolve()),dest])
        for k,v in dict(PATH='/usr/bin:/bin',HOME='/tmp',LANG='C.UTF-8',**env).items():cmd.extend(['--setenv',k,v])
    else:cmd=command(work,mounts=parts,env=env)
    cmd+=[a.replace('@DRAW@','/workspace/build/'+str(lib/'bin/DRAWEXE')) for a in args]
    with log.open('wb') as f:p=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,timeout=140)
    if p.returncode:raise RuntimeError(log.read_text(errors='replace')[-1100:])
def take(work,rt,artifact,d):
    invoke(rt,work,['@DRAW@','-b','-f','/study/same.tcl'],work/'same.log',mounts=[(artifact,'/artifact',False)])
    invoke(F,work,['/readers/trim','/artifact'],work/'trim.log',mounts=[(artifact,'/artifact',False)])
    if d:invoke(F,work,['/old-bin/F-observer','/artifact','/input/points-'+d+'.txt'],work/'adaptive.log',mounts=[(artifact,'/artifact',False)])
def phase_one():
    comp=S/'compile'
    invoke(F,comp,['clang++-10','-O2','-std=c++14','-I/workspace/build/include/opencascade','/study/trim_integrals.cxx',
        '-L/workspace/build/lin64/clang/lib','-lTKTopAlgo','-lTKBRep','-lTKGeomBase','-lTKG3d','-lTKG2d','-lTKMath','-lTKernel','-o','trim'],
        comp/'compiler.log')
    (comp/'trim').replace(S/'readers/trim')
    for name in ['cone','cylinder','zero','in','out']:
        prior=OLD/'runs/F/brep'/name/'1/draw.brep'
        if name in ('cone','cylinder'):prior=OLD/'inputs'/('bug25542_'+name+'.brep')
        take(S/'locked793'/name,F,prior,name if name in ('zero','in','out') else None)
        (S/'locked793'/name/'brep.sha256').write_text(sha(prior)+'\n')
def evaluate(label,rt,rep,d):
    job=S/'results'/label/d/str(rep)
    if job.exists():raise FileExistsError(job)
    g=read(OLD/'gold.json')[d]
    if label=='fix2018':
        invoke(rt,job,['@DRAW@','-b','-f','/study/native_draw.tcl'],job/'run.log',dict(DELTA=str(g['delta']),FORM='brep'))
        assert 'AUDIT_DRAW_COMPLETE' in (job/'run.log').read_text()
        take(job,rt,job/'output.brep',d)
        return
    invoke(rt,job,['@DRAW@','-b','-f','/study/compat/cases/single20/occt-25542/1/case.tcl'],job/'run.log',
           dict(DELTA=str(g['delta']),EXPECTED_AREA=str(g['fine']['area']),CONTROL='candidate',SUBSTITUTE='zero'))
    t=(job/'run.log').read_text(errors='replace')
    if 'STUDY_SAVED' not in t or not (job/'output.brep').is_file():raise RuntimeError(t[-800:])
    take(job,rt,job/'output.brep',d)
def run(rt,label):
    rec=rt/'receipt.json'
    if rec.is_file():
        meta=read(rec)
        if not meta.get('source_commit') or not meta.get('source_tree_sha256'):raise ValueError('Missing identity')
        tree=tree_sha256(rt/'source')
        assert tree==meta['source_tree_sha256']
        origin=dict(commit=meta['source_commit'],tree=tree,receipt_sha256=sha(rec),git_tree=meta.get('git_tree'))
    else:origin=read(rt/'verified.json')
    lib=layout(rt)[0];libdir=rt/'build'/lib/'lib'
    files={p.name:sha(p) for p in [rt/'build'/lib/'bin/DRAWEXE']+[libdir/(n+'.so') for n in ('libTKTopTest','libTKDraw','libTKBRep','libTKGeomAlgo','libTKBO','libTKTopAlgo','libTKernel')]}
    manifest=rt/'binary-manifest.json'
    if manifest.exists():
        assert read(manifest)['build_receipt_sha256']==sha(rec)
        for name,h in read(manifest)['libraries'].items():
            assert sha(rt/'build'/name)==h,name
    elif rec.is_file():
        for name,h in meta.get('libraries',{}).items():
            check=libdir/name
            if check.is_file():assert sha(check)==h,name
    (S/'identities').mkdir(exist_ok=True)
    save(S/'identities'/(label+'.json'),dict(runtime=str(rt),**origin,binaries=files))
    for i in (1,2):
        for d in ('in','out'):evaluate(label,rt,i,d)
if __name__=='__main__':
    (S/'readers').mkdir(exist_ok=True)
    if sys.argv[1]=='first':phase_one()
    else:run(Path(sys.argv[3]),sys.argv[2])
