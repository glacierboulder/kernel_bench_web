"""Read six assertions and independently compare a sealed BREP with the two analytic integrals."""
import hashlib
import json
import math
import re
from pathlib import Path

ROOT = Path(__file__).resolve().parent
ASSERTIONS = ['input_validity', 'operation_completed', 'validity', 'component_count', 'measure', 'centroid_domain']

def read(path):
    return json.loads(path.read_bytes())

def write(path, obj):
    path.write_text(json.dumps(obj, indent=2, allow_nan=False) + '\n')

def sha(path):
    return hashlib.sha256(path.read_bytes()).hexdigest()

def assertions(path, target):
    log = path.read_text()
    checks = re.findall(r'^BENCH_ASSERT_(PASS|FAIL) (\w+) (.*)$', log, re.M)
    assert 'TEST_DONE assertions=6 numeric_assertions=3' in log and [s[1] for s in checks] == ASSERTIONS, path
    match = re.search(r'observed=([^ ]+) expected=([^ ]+) limit=([^ ]+)', checks[4][2])
    observed, expected, limit = map(float, match.groups())
    assert expected == target and limit == abs(target) * 1e-4
    assert (abs(observed - target) <= limit) == (checks[4][0] == 'PASS')
    return {'failed': [c[1] for c in checks if c[0]=='FAIL'], 'area': observed, 'area_error': observed-target}

def measure(path, gold, criteria):
    lines = [line.split() for line in path.read_text().splitlines()]
    def fields(name):
        return [[float(x) for x in row[1:]] for row in lines if row and row[0] == name]
    (valid, solids, shells, faces, closed), = fields('SHAPE')
    (total, wrong, unknown), = fields('POINTS')
    assert total == gold['inside'] + gold['outside']
    coarse, fine = fields('MASS')
    assert [coarse[0], fine[0]] == [1e-7, 1e-10]
    status = {}
    error = {}
    drift = {}
    for index, key in enumerate(('volume','area'), 1):
        delta = fine[index] - gold['fine'][key]
        change = abs(coarse[index] - fine[index])
        limit = criteria[key+'_absolute']
        assert math.isfinite(delta) and math.isfinite(change), path
        error[key] = delta
        drift[key] = change
        if abs(delta) > limit + 2*change:
            status[key] = 'FAIL'
        elif abs(delta) + 2*change > limit:
            status[key] = 'INCONCLUSIVE'
        else:
            status[key] = 'PASS'
    status['topology'] = 'PASS' if valid and solids==1 and closed and shells else 'FAIL'
    status['points'] = 'FAIL' if wrong else ('INCONCLUSIVE' if unknown else 'PASS')
    outcome = 'FAIL' if 'FAIL' in status.values() else ('INCONCLUSIVE' if 'INCONCLUSIVE' in status.values() else 'PASS')
    return dict(status=outcome, checks=status, error=error, drift=drift,
                solids=int(solids), witnesses=[int(v) for v in (total,wrong,unknown)])

def grade(job, gold, criteria):
    target = gold['fine']['area']
    native = None
    if (job/'native.log').exists():
        producer = (job/'native.log').read_text()
        if 'BENCH_ASSERT_' in producer:
            native = assertions(job/'native.log', target)
            assert not {'input_validity','operation_completed'}.intersection(native['failed'])
        else:
            assert 'AUDIT_DRAW_COMPLETE' in producer and 'INPUT This shape seems to be valid This shape seems to be valid' in producer
    sealed = assertions(job/'six.log', target)
    assert not {'input_validity','operation_completed'}.intersection(sealed['failed'])
    geom = measure(job/'adaptive.log', gold, criteria)
    formal = 'FAIL' if sealed['failed'] or (native and native['failed']) else 'PASS'
    outcome = 'FAIL' if formal == 'FAIL' else geom['status']
    return dict(status=outcome, formal=formal, native=native, sealed=sealed, geometry=geom, sha256=sha(job/'output.brep'))
