import math

def rotated(p,pose):
    o=pose[:3]; u=pose[3:6]; norm=math.sqrt(sum(x*x for x in u))
    x,y,z=[(v-b) for v,b in zip(p,o)]; l,m,n=[v/norm for v in u]
    c=math.cos(math.radians(pose[6]));s=math.sin(math.radians(pose[6]));dot=l*x+m*y+n*z
    return [base+k*c+cross*s+axis*dot*(1-c) for base,k,cross,axis in zip(o,[x,y,z],[m*z-n*y,n*x-l*z,l*y-m*x],[l,m,n])]
