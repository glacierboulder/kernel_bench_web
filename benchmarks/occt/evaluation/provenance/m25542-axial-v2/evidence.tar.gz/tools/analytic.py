"""Independent cross sections and polar-column integral for two vertical finite primitives."""
import json
import math
from pathlib import Path
from math import acos, atan2, cos, fsum, hypot, pi, sin, sqrt

R, H, B = 50., 130., 19.96650334339979
X, Y = 33.557878661169568, 37.065735926354144
HERE = Path(__file__).resolve().parent


def integrate(f, lo, hi, n):
    # Cosine substitution resolves square-root behavior at circle tangencies.
    if hi <= lo:
        return 0.
    return fsum(f(lo + (hi-lo)*sin(pi*i/(2*n))**2) * sin(pi*i/n) *
                (4 if i%2 else 2) for i in range(1,n)) * (hi-lo)*pi/(6*n)


def angles(r, d):
    if r <= abs(R-d):
        return (pi if d < R else 0.), 0.
    twice_triangle = sqrt(max(0., (r+d+R)*(r+d-R)*(R+d-r)*(R-d+r)))
    return atan2(twice_triangle, (d-R)*(d+R)+r*r), atan2(twice_triangle, d*d+R*R-r*r)


def lens(r, d):
    a,b = angles(r,d)
    return r*r*(a-.5*sin(2*a)) + R*R*(b-.5*sin(2*b))


def properties(delta,n):
    d = hypot(X,Y)+delta
    split = abs(R-d)
    def radial(fn):
        return integrate(fn,0,split,n)+integrate(fn,split,B,n)
    volume = radial(lambda r:lens(r,d))*H/B
    area = lens(B,d)+radial(lambda r: 2*r*angles(r,d)[0]*hypot(B,H)/B + 2*R*angles(r,d)[1]*H/B)
    # At polar radius r around the cone axis, integrate its height over each
    # column whose base is inside the cylinder. This does not use lens areas.
    def half_angle(r):
        if r <= split:
            return pi if d<R else 0.
        return acos(max(-1.,min(1.,(r*r+(d-R)*(d+R))/(2*d*r))))
    polar = radial(lambda r:2*r*half_angle(r)*H*(1-r/B))
    # Bottom and conical side from visible ring length. Cylinder side from
    # vertical strips along the cylinder boundary, using the height of the cone.
    arc = 2*math.asin(sqrt((B*B-(d-R)**2)/(4*d*R)))
    cylinder_area = 2*R*integrate(lambda t:H*(1-hypot(d-R,2*sqrt(R*d)*sin(t/2))/B),0,arc,n)
    area2 = (1+hypot(B,H)/B)*radial(lambda r:2*r*half_angle(r))+cylinder_area
    return dict(volume=volume,area=area,polar_volume=polar,strip_area=area2)


def witnesses(delta):
    d = hypot(X,Y)+delta
    ux,uy=X/hypot(X,Y),Y/hypot(X,Y)
    pts=[]
    for z in (3.,37.,81.,117.,128.):
        radius=B*(1-z/H)
        for a in (-1.21,-.83,-.45,-.13,.13,.45,.83,1.21):
            for b in (-.77,-.22,.22,.77):
                x,y=d+a*radius,b*radius
                m1=R-hypot(x,y)
                m2=(radius-hypot(x-d,y))/hypot(1,B/H)
                if min(abs(m1),abs(m2),z,H-z)<.06:
                    continue
                pts.append((x*ux-y*uy,x*uy+y*ux,z,int(min(m1,m2)>0)))
    return pts


if __name__=='__main__':
    result={}
    for name,delta in [('in',-.01),('zero',0.),('out',.01)]:
        coarse=properties(delta,2048)
        fine=properties(delta,8192)
        assert max(abs(fine[k]-coarse[k]) for k in fine)<1e-6
        assert abs(fine['volume']-fine['polar_volume'])<1e-7
        assert abs(fine['area']-fine['strip_area'])<1e-7
        pts=witnesses(delta)
        (HERE/'inputs'/('points-'+name+'.txt')).write_text(''.join('%.16g %.16g %.16g %d\n'%p for p in pts))
        result[name]=dict(delta=delta,axis_distance=hypot(X,Y)+delta,coarse=coarse,fine=fine,
                          inside=sum(p[-1] for p in pts),outside=sum(1-p[-1] for p in pts))
    (HERE/'gold.json').write_text(json.dumps(result,indent=2)+'\n')
