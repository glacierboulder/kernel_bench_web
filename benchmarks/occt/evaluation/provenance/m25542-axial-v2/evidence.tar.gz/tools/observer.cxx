// One fixed, read-only OCCT 7.9.3 reader for output from all three kernels.
#include <BRepTools.hxx>
#include <BRep_Builder.hxx>
#include <BRepCheck_Analyzer.hxx>
#include <BRepClass3d_SolidClassifier.hxx>
#include <BRepGProp.hxx>
#include <BRep_Tool.hxx>
#include <GProp_GProps.hxx>
#include <TopExp.hxx>
#include <TopExp_Explorer.hxx>
#include <TopoDS.hxx>
#include <TopTools_IndexedMapOfShape.hxx>
#include <iostream>
#include <iomanip>
#include <fstream>
int main(int argc,char** argv) {
  if(argc!=3) return 2;
  TopoDS_Shape shape;BRep_Builder b;
  if(!BRepTools::Read(shape,argv[1],b)||shape.IsNull())return 3;
  std::cout<<std::setprecision(16);
  TopTools_IndexedMapOfShape solids,shells,faces;
  TopExp::MapShapes(shape,TopAbs_SOLID,solids);
  TopExp::MapShapes(shape,TopAbs_SHELL,shells);
  TopExp::MapShapes(shape,TopAbs_FACE,faces);
  bool closed=true;
  for(int i=1;i<=shells.Extent();++i)closed &= BRep_Tool::IsClosed(shells(i));
  std::cout<<"SHAPE "<<BRepCheck_Analyzer(shape).IsValid()<<" "<<solids.Extent()<<" "<<shells.Extent()<<" "<<faces.Extent()<<" "<<closed<<"\n";
  for(double eps: {1e-7,1e-10}) {
    GProp_GProps v,s;
    BRepGProp::VolumeProperties(shape,v,eps);
    BRepGProp::SurfaceProperties(shape,s,eps);
    std::cout<<"MASS "<<eps<<" "<<v.Mass()<<" "<<s.Mass()<<"\n";
  }
  std::ifstream in(argv[2]); if(!in) return 4;
  double x,y,z;int expect;
  int n=0,wrong=0,uncertain=0;
  BRepClass3d_SolidClassifier classifier;
  if(solids.Extent()==1) classifier.Load(solids(1));
  while(in>>x>>y>>z>>expect){
    TopAbs_State s=TopAbs_OUT;
    if(solids.Extent()==1){classifier.Perform(gp_Pnt(x,y,z),1e-7);s=classifier.State();}
    else if(solids.Extent()>1){s=TopAbs_UNKNOWN;}
    ++n;
    if(s==TopAbs_ON || s==TopAbs_UNKNOWN)++uncertain;
    else if((s==TopAbs_IN)!=bool(expect)){++wrong;std::cout<<"MISS "<<x<<" "<<y<<" "<<z<<" "<<expect<<" "<<int(s)<<"\n";}
  }
  std::cout<<"POINTS "<<n<<" "<<wrong<<" "<<uncertain<<"\n";
}
