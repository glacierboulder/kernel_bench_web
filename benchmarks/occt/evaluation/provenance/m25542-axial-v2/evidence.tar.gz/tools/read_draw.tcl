set ::tcl_library /home/lzy/cad-bench-experiment/runtime/py311/lib/tcl8.6
source [file join $::tcl_library init.tcl]
source /qualified/tools/assertions.tcl
source /qualified/tools/solid_checks.tcl
pload TOPTEST
if {[catch {
    foreach s {first second result} {restore /art/$s.brep $s}
    set check 1
    foreach s {first second} {
        if {[string first "This shape seems to be valid" [checkshape $s]] < 0} {set check 0}
    }
    ::single20::assert input_validity $check "valid=$check"
    set validity [checkshape result]
    ::single20::assert validity [expr {[string first "This shape seems to be valid" $validity]>=0}] $validity
    regexp {SOLID\s*:\s*([0-9]+)} [nbshapes result] -> count
    ::single20::assert component_count [expr {$count==1}] "solids=$count" numeric
    set area [::single20::mass sprops result]
    ::single20::assert measure [expr {abs($area-$::env(EXPECT_AREA))<=abs($::env(EXPECT_AREA))*1e-4}] "area=$area expected=$::env(EXPECT_AREA)" numeric
    set bound1 [::single20::bounds first]; set bound2 [::single20::bounds second]
    set ok 0
    if {![catch {sprops result cx cy cz -full; set center [list [dval cx] [dval cy] [dval cz]]}]} {
        set ok 1
        for {set i 0} {$i<3} {incr i} {
            set v [lindex $center $i]; set j [expr {$i+3}]
            if {![::single20::finite $v] || $v < max([lindex $bound1 $i],[lindex $bound2 $i])-1e-5 || $v > min([lindex $bound1 $j],[lindex $bound2 $j])+1e-5} {set ok 0}
        }
    }
    ::single20::assert centroid_domain $ok "centroid_in_shared_domain=$ok" numeric
    ::single20::finish
} msg]} {puts stderr "READER_ERROR $::errorInfo"}
