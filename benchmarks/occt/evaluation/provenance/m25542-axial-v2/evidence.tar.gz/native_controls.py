from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
from evaluate import ROOT,runtimes,runner,load,sha,write,verify
import re
snap=ROOT/'final/benchmark-snapshot'
suite=load(snap/'suite.json');gate=load(ROOT/'gate.json')['qualified']
verify('F')
def one(pair):
    pose,mode=pair
    w=ROOT/'registered-controls'/pose/mode;w.mkdir(parents=True)
    cp=next(c for c in suite['checkpoints'][4:] if c['category']==gate[pose]['role'])
    raw=ROOT/'jobs'/mode/pose/'1'
    assert sha(raw/'result.brep')==load(raw/'score.json')['sha256']
    runner.invoke(runtimes['F'],w,['@DRAW@','-b','-f','/control.tcl'],w/'draw.log',dict(CASE_FILE=Path(cp['case']).name),
          [(snap/'supervisor/cases/bundle','/suite-cases',False),(ROOT/'tools/registered_control.tcl','/control.tcl',False),(raw/'result.brep','/control-result.brep',False)])
    log=(w/'draw.log').read_text();items=re.findall(r'^BENCH_ASSERT_(PASS|FAIL) (\w+).* kind=(numeric|expression)$',log,re.M)
    ids=[n for _,n,_ in items]
    assert ids==cp['runner_options']['expected_assertion_ids'][1:] and log.splitlines().count('__BENCH_ORACLE_COMPLETE__')==1,log[-1300:]
    counts=f"assertions={len(ids)} numeric_assertions={sum(k=='numeric' for _,_,k in items)}"
    assert all(log.splitlines().count(m+counts)==1 for m in ('TEST_DONE ','BENCH_ORACLE_OK '))
    failed=[n for status,n,_ in items if status=='FAIL']
    assert bool(failed)==(mode!='gold') and not set(failed)&{'first_valid','second_valid','operand_membership'}
    if mode=='shifted':assert 'result_membership' in failed and not set(failed)&{'volume','area'}
    write(w/'receipt.json',dict(status='FAIL' if failed else 'PASS',failed=failed,sha256=sha(w/'draw.log'),shape=sha(raw/'result.brep')))
with ThreadPoolExecutor(max_workers=3) as pool:list(pool.map(one,((p,m) for p in gate for m in ('gold','shifted','cone','empty'))))
