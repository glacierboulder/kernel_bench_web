#include "arc_v2.hxx"
int main(int argc,char** argv) {
  if(argc<3) return 2;
  const std::string action=argv[1];
  const bool healthy=std::string(argv[2])=="healthy";
  if(action=="save") return arc_v2::run(healthy,true);
  auto c=arc_v2::makeCase(healthy);
  if(action=="read" && argc==4){
    TopoDS_Shape shp;
    if(!BRepTools::Read(shp,argv[3],BRep_Builder())) return 4;
    return arc_v2::check(c,shp)?0:1;
  }
  if(action!="controls") return 2;
  const double a=c.lo,b=c.hi;
  const auto exact=BRepBuilderAPI_MakeEdge(c.support,a,b).Edge();
  const auto half=BRepBuilderAPI_MakeEdge(c.support,a,(a+b)/2).Edge();
  const auto adjacent=BRepBuilderAPI_MakeEdge(c.support,b,2*b-a).Edge();
  BRepAdaptor_Curve ref(exact);
  const auto chord=BRepBuilderAPI_MakeEdge(ref.Value(a),ref.Value(b)).Edge();
  bool ok=true;
  for (const auto& item : {std::make_pair("exact",exact),{"half",half},{"adjacent",adjacent},{"chord",chord}}) {
    std::cout<<item.first<<" ";
    if(arc_v2::check(c,item.second)!=(item.second.IsSame(exact))) ok=false;
  }
  return ok?0:1;
}
