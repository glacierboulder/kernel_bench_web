"""Run the exact registered compiler, process limits, library list and output markers."""
import json
import os
from pathlib import Path
import sys
from suite_driver import _execute

root = Path('/workspace')
os.environ.update(BENCH_CXX='/usr/bin/g++-13', BENCH_TOOLCHAIN_NAME='gcc')
suite = json.loads((root/'suite.json').read_text())
results = {}
for check in suite['checkpoints']:
    results[check['id']] = _execute(check, case_root=root, build=root/'build',
                                    source=root/'source', work=root, draw_runner=Path('/unused'))
(root/'native.json').write_text(json.dumps(results,indent=2)+'\n')
