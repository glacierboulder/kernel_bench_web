"""Select on B/F only. Native and fixed-reader grade must both pass on F."""
from pathlib import Path
import shutil
from study import ROOT,OUT,HISTORY,WARM,replay,write,run,sources
n='28366'
items=[(53,0,0),(0,17,-13),(17,0,0),(67,0,0)]
dest=ROOT/'diagnostic/screen'
dest.mkdir(parents=True,exist_ok=True)
sources(n,dest)
p=dest/'slice_v2.hxx'
p.write_text((ROOT/'diagnostic/translation/slice_v2.hxx').read_text().replace('namespace slice_v2 {','namespace slice_v2 {\ninline double u,x,y;').replace('gp_Vec(17,-13,9)','gp_Vec(x,y,0)').replace('healthy?0.:53.','healthy?0.:u'))
cpp=(ROOT/'tools/slice_control.cpp').read_text().replace('if(argc<3) return 2;','if(argc<6) return 2;\n  slice_v2::u=std::stod(argv[argc-3]); slice_v2::x=std::stod(argv[argc-2]); slice_v2::y=std::stod(argv[argc-1]); argc-=3;')
(dest/'screen.cpp').write_text(cpp)
replay.compile_case(WARM,dest,'screen.cpp','screen')
records=[]
for i,item in enumerate(items):
    d={'angle_x_y':item}
    for name,rt in [('B',WARM),('F',HISTORY/'reference'/n)]:
        w=dest/(str(i)+'-'+name)
        w.mkdir(exist_ok=True)
        sources(n,w)
        shutil.copy2(dest/'screen',w/'screen')
        vals=list(map(str,item))
        producer=run(rt,w,['./screen','save','defect',*vals],'producer')
        observer=run(WARM,w,['./screen','read','defect','section.brep',*vals],'observer')
        d[name]=[producer,observer]
    records.append(d)
    print(d,flush=True)
    if d['B'][0]==1 and d['F']==[0,0]:break
write(dest/'screen.json',records)
