#include "slice_v2.hxx"
int main(int argc,char** argv) {
  if(argc<3) return 2;
  const bool healthy=std::string(argv[2])=="healthy";
  const std::string action=argv[1];
  if(action=="save") return slice_v2::run(healthy,true);
  if(argc!=4) return 2;
  const auto c=slice_v2::makeCase(healthy);
  TopoDS_Shape s;
  if(!BRepTools::Read(s,argv[3],BRep_Builder())) return 4;
  if(action=="read") return slice_v2::check(c,s)?0:1;
  if(action!="controls") return 2;
  TopoDS_Compound empty;
  BRep_Builder().MakeCompound(empty);
  bool ok=slice_v2::check(c,s);
  std::cout<<"empty ";
  if(slice_v2::check(c,empty)) ok=false;
  for(const auto& pair:{std::make_pair("same_area_in_plane",gp_Vec(0,10000,0)),
                        std::make_pair("wrong_plane",gp_Vec(0,0,.001))}){
    gp_Trsf t;
    t.SetTranslation(pair.second.Transformed(c.move));
    std::cout<<pair.first<<" ";
    if(slice_v2::check(c,s.Moved(TopLoc_Location(t)))) ok=false;
  }
  return ok?0:1;
}
