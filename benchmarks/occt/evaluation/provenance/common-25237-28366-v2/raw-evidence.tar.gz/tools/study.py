"""Supervisor: calibrate on B/F, seal inputs, then replay byte-verified timed finals."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess
import sys
from concurrent.futures import ThreadPoolExecutor

ROOT=Path(__file__).resolve().parents[1]
HISTORY=Path('/var/tmp/cad-common-fresh15-20261119')
sys.path.insert(0,str(HISTORY))
import replay
TASKS=('25237','28366')
WARM=HISTORY/'public-runtime'
CASE=ROOT/'evaluation/cases'
SUITES=ROOT/'evaluation/suites'
OUT=ROOT/'evidence'

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def load(p): return json.loads(p.read_bytes())
def write(p,data): p.write_text(json.dumps(data,indent=2)+'\n')
def suite(n): return SUITES/f'occt-{n}-suite'/'2.json'
def frozen():
    files=[p for parent in [CASE,SUITES,ROOT/'tools'] for p in parent.rglob('*')
           if p.is_file() and p.suffix not in ('.pyc',)]+[ROOT/'protocol.md',ROOT/'suite_driver.py']
    return {str(p.relative_to(ROOT)):sha(p) for p in sorted(files)}

def require(condition,message):
    if not condition: raise RuntimeError(str(message))

def run(rt,work,args,name):
    f=work/(name+'.log')
    code=replay.sandbox(rt,work,args,f,600)
    if code not in (0,1): raise RuntimeError((args,code,f.read_text()[-2000:]))
    return code

def sources(n,path):
    sources=CASE/f'occt-{n}'
    for p in sources.iterdir():
        if p.suffix in ('.txt','.brep','.hxx'): shutil.copy2(p,path)
    for p in sources.glob('*.brep'):
        require(sha(p)==sha(HISTORY/'locked'/n/p.name),p)

def compile_controls(n):
    dest=OUT/n/'verifier'
    dest.mkdir(exist_ok=True,parents=True)
    sources(n,dest)
    src=ROOT/'tools'/('arc_control.cpp' if n=='25237' else 'slice_control.cpp')
    shutil.copy2(src,dest/'control.cpp')
    replay.compile_case(WARM,dest,'control.cpp','control')

def record(n,label,rt,repetitions):
    work=OUT/n/label
    work.mkdir(parents=True,exist_ok=True)
    shutil.copytree(CASE/f'occt-{n}',work/'evaluation/cases'/f'occt-{n}',dirs_exist_ok=True)
    shutil.copy2(suite(n),work/'suite.json')
    shutil.copy2(ROOT/'suite_driver.py',work)
    shutil.copy2(ROOT/'tools/inside.py',work)
    code=run(rt,work,['/usr/bin/python3','inside.py'],'driver')
    require(code==0,(work/'driver.log').read_text())
    native=load(work/'native.json')
    for k,v in native.items():
        require(v.get('phase')!='compile' and not v['result']['timed_out']
                and v['result']['return_code'] in (0,1),(n,label,k,v))
    extended={}
    for i,cp in enumerate(load(suite(n))['checkpoints'][4:]):
        role=('defect','healthy')[i]
        entries=[]
        for rep in range(repetitions):
            dest=work/(role+str(rep+1))
            dest.mkdir(exist_ok=True)
            sources(n,dest)
            shutil.copy2(OUT/n/'verifier/control',dest)
            producer=run(rt,dest,['./control','save',role],'producer')
            shapes=('forward.brep','reverse.brep') if n=='25237' else ('section.brep',)
            reader={s:run(WARM,dest,['./control','read',role,s],'reader-'+s) for s in shapes}
            require((producer==0)==native[cp['id']]['passed'],('producer disagrees',n,label,role))
            if label=='F':
                args=['./control','controls',role]+([] if n=='25237' else ['section.brep'])
                require(run(WARM,dest,args,'controls')==0,(n,label,role,'controls'))
            entries.append(dict(producer=producer,reader=reader,shapes={s:sha(dest/s) for s in shapes}))
        extended[cp['id']]=entries
    result={k:v['passed'] for k,v in native.items()}
    for k,entries in extended.items():
        result[k]=result[k] and all(e['producer']==0 and all(v==0 for v in e['reader'].values()) for e in entries)
    write(work/'outcomes.json',dict(status=result,extended=extended))
    print(n,label,result,flush=True)
    return result

def calibrate():
    tasks=sys.argv[2:] or TASKS
    for n in tasks:
        compile_controls(n)
    with ThreadPoolExecutor(2) as pool:
        for n in tasks:
            b,f=list(pool.map(lambda item:record(n,*item,2),[('B',WARM),('F',HISTORY/'reference'/n)]))
            require(list(b.values())==[False,False,False,True,False,True] and all(f.values()),(b,f))
    for n in TASKS:
        for side,expected in [('B',[False,False,False,True,False,True]),('F',[True]*6)]:
            require(list(load(OUT/n/side/'outcomes.json')['status'].values())==expected,(n,side))
    write(OUT/'seal.json',frozen())

def prepare(n,trial):
    rt=ROOT/'scratch'/(n+'-'+trial)
    rt.mkdir(parents=True,exist_ok=False)
    for name in ('source','build'):
        subprocess.run(['cp','-a','--reflink=auto',str((WARM/name).resolve()),str(rt/name)],check=True)
    (rt/'tools').mkdir()
    shutil.copy2(HISTORY/'trial/tools/build.sh',rt/'tools/build.sh')
    p=ROOT/'patches'/n/trial/'patch.diff'
    capture=load(p.parent/'capture.json')
    require(sha(p)==capture['sha256'] and capture['base']==load(WARM/'verified.json')['commit'],p)
    dest=OUT/n/trial
    dest.mkdir(exist_ok=True,parents=True)
    with (dest/'apply.log').open('wb') as log:
        subprocess.run(['git','apply','--check',str(p)],cwd=rt/'source',stdout=log,stderr=subprocess.STDOUT,check=True)
        subprocess.run(['git','apply',str(p)],cwd=rt/'source',stdout=log,stderr=subprocess.STDOUT,check=True)
    args=['/usr/bin/taskset','-c','2,3' if n=='25237' else '4,5','/usr/bin/bwrap',
          '--unshare-all','--die-with-parent','--ro-bind',str(replay.IMAGE),'/', '--dev','/dev',
          '--proc','/proc','--tmpfs','/tmp','--ro-bind',str(rt),'/workspace',
          '--bind',str(rt/'build'),'/workspace/build','--chdir','/workspace',
          '--setenv','HOME','/tmp','--setenv','PATH','/usr/bin:/bin','/bin/bash','/workspace/tools/build.sh']
    with (dest/'build.log').open('wb') as log:
        subprocess.run(args,stdout=log,stderr=subprocess.STDOUT,timeout=3600,check=True)
    write(dest/'build.json',dict(commit=capture['base'],patch_sha256=sha(p),apply=0,build=0,
          TKBO=sha(rt/'build/lin64/gcc/lib/libTKBO.so.8.0.1')))
    return rt

def final(n):
    for trial in ('trial1','trial2'):
        rt=prepare(n,trial)
        record(n,trial,rt,1)
        # The previous v1 independent reader also remains part of this retrospective score.
        work=OUT/n/trial
        extra=replay.run_geometry(rt,n,work/'legacy-geometry')
        write(work/'legacy-geometry.json',extra)
        shutil.rmtree(rt)

if __name__=='__main__':
    if sys.argv[1]=='calibrate': calibrate()
    elif sys.argv[1]=='final':
        require(load(OUT/'seal.json')==frozen(),'calibration inputs changed')
        with ThreadPoolExecutor(2) as pool: list(pool.map(final,TASKS))
