from pathlib import Path
import hashlib,json,shutil,sys,tempfile,subprocess
root=Path(__file__).resolve().parent
sys.path.insert(0,str(root/'catalog-check'))
from backend.source_cache import tree_sha256
hist=Path('/var/tmp/cad-common-fresh15-20261119')
warm=hist/'public-runtime'
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
identity=json.loads((warm/'verified.json').read_bytes())
tree=tree_sha256(warm/'source')
assert tree==identity['tree']
assert all(sha(warm/'build'/n)==h for n,h in identity['binary_sha256'].items())
out={'warm_artifacts':identity,'verified_warm_sha256':sha(warm/'verified.json'),'references':{}}
for n in ('25237','28366'):
    patch=hist/'locked'/n/'reference.patch'
    expected=root/'catalog-check/benchmarks/occt/evaluation/provenance'/('geometry-'+n)/'reference.patch'
    assert sha(patch)==sha(expected)
    with tempfile.TemporaryDirectory(dir=root) as temp:
        src=Path(temp)/'source'
        shutil.copytree((warm/'source').resolve(),src,symlinks=True)
        subprocess.run(['git','apply',str(patch)],cwd=src,check=True)
        expected_tree=tree_sha256(src)
    actual=hist/'reference'/n
    assert expected_tree==tree_sha256(actual/'source')
    out['references'][n]={'tree':expected_tree,'patch':sha(patch),'libTKBO':sha(actual/'build/lin64/gcc/lib/libTKBO.so.8.0.1')}
(root/'evidence/identity.json').write_text(json.dumps(out,indent=2)+'\n')
