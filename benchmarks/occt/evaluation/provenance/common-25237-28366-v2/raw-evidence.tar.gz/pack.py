"""Pack small raw checkpoints and geometry, without executable or build cache files."""
from pathlib import Path
import tarfile
import hashlib
import json

root=Path(__file__).resolve().parent
files=[]
for name in ('tools','evidence','patches','diagnostic','evaluation','reference'):
    for p in (root/name).rglob('*'):
        if not p.is_file() or p.name.startswith('._') or '__pycache__' in p.parts:
            continue
        if p.suffix in ('.json','.log','.cpp','.hxx','.txt','.py','.diff','.patch','.sh'):
            if (name in ('evidence','diagnostic') and p.suffix in ('.txt','.hxx','.cpp','.py')
                and not (name=='diagnostic' and p.name in ('screen.cpp','slice_v2.hxx') and (p.parent.name in ('tilt','translation','screen')))):
                continue
        elif p.suffix=='.brep':
            if name != 'evaluation' and p.name not in ('forward.brep','reverse.brep','section.brep') and p.parent.name!='legacy-geometry':
                continue
            if p.name.startswith(('fuselage','bug25237')) and name!='evaluation':continue
        else:continue
        files.append(p)
files+=[root/'suite_driver.py',root/'protocol.md',root/'identity.py',root/'pack.py']
manifest={str(p.relative_to(root)):hashlib.sha256(p.read_bytes()).hexdigest() for p in sorted(files)}
(root/'file-hashes.json').write_text(json.dumps(manifest,indent=2)+'\n')
with tarfile.open(root/'raw-evidence.tar.gz','w:gz') as t:
    for p in sorted(files)+[root/'file-hashes.json']:
        t.add(p,arcname=str(p.relative_to(root)),recursive=False)
