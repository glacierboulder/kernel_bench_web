// Derive the expected XY section from the oriented triangulated input boundary.
#include <BRepAlgoAPI_Common.hxx>
#include <BRepBuilderAPI_MakeFace.hxx>
#include <BRepCheck_Analyzer.hxx>
#include <BRepClass_FaceClassifier.hxx>
#include <BRepGProp.hxx>
#include <BRepMesh_IncrementalMesh.hxx>
#include <BRepTools.hxx>
#include <BRep_Builder.hxx>
#include <BRep_Tool.hxx>
#include <BRepAdaptor_Surface.hxx>
#include <GProp_GProps.hxx>
#include <Poly_Triangulation.hxx>
#include <TopExp_Explorer.hxx>
#include <TopoDS.hxx>
#include <gp_Ax3.hxx>
#include <gp_Pln.hxx>
#include <fstream>
#include <iomanip>
#include <iostream>
#include <cmath>
#include <algorithm>
#include <limits>
#include <vector>
#include <string>

struct Segment { gp_Pnt start,end; };
TopoDS_Shape readSolid()
{
  std::ifstream stream("fuselage-derived.brep");
  std::string header;
  std::getline(stream,header);
  TopoDS_Shape shape;
  BRepTools::Read(shape,stream,BRep_Builder());
  return shape;
}

std::vector<Segment> cutMesh(const TopoDS_Shape& solid, double z)
{
  std::vector<Segment> lines;
  for (TopExp_Explorer it(solid,TopAbs_FACE); it.More();it.Next())
  {
    TopoDS_Face face=TopoDS::Face(it.Current());
    TopLoc_Location loc;
    const auto tri=BRep_Tool::Triangulation(face,loc);
    if (tri.IsNull()) throw std::runtime_error("unmeshed face");
    for (int i=1;i<=tri->NbTriangles();++i)
    {
      int ia,ib,ic;
      tri->Triangle(i).Get(ia,ib,ic);
      if(face.Orientation()==TopAbs_REVERSED) std::swap(ib,ic);
      const gp_Pnt points[] = {tri->Node(ia).Transformed(loc.Transformation()),
                               tri->Node(ib).Transformed(loc.Transformation()),
                               tri->Node(ic).Transformed(loc.Transformation())};
      gp_Pnt cuts[2];
      int n=0;
      for (int j=0;j<3;++j)
      {
        const gp_Pnt &p=points[j],&q=points[(j+1)%3];
        if ((p.Z()>z)==(q.Z()>z)) continue;
        const double u=(z-p.Z())/(q.Z()-p.Z());
        cuts[n++]=p.Translated(gp_Vec(p,q)*u);
      }
      if (n!=2 || cuts[0].SquareDistance(cuts[1])<1e-22) continue;
      const gp_Vec normal=gp_Vec(points[0],points[1]).Crossed(gp_Vec(points[0],points[2]));
      if (gp_Vec(cuts[0],cuts[1]).Dot(gp_Vec(-normal.Y(),normal.X(),0))<0.)
        std::swap(cuts[0],cuts[1]);
      lines.push_back({cuts[0],cuts[1]});
    }
  }
  return lines;
}

double sectionArea(const std::vector<Segment>& lines)
{
  long double flux=0.;
  for(const auto& edge:lines)
    flux+=(long double)edge.start.X()*edge.end.Y()-(long double)edge.start.Y()*edge.end.X();
  return 0.5*double(flux);
}

double distance(const gp_Pnt& p,const Segment& edge)
{
  const gp_Vec delta(edge.start,edge.end);
  const double u=std::clamp(gp_Vec(edge.start,p).Dot(delta)/delta.SquareMagnitude(),0.,1.);
  return p.Distance(edge.start.Translated(delta*u));
}

bool contains(const std::vector<Segment>& lines,const gp_Pnt& p)
{
  int winding=0;
  for(const auto& e:lines)
  {
    const auto& a=e.start;const auto& b=e.end;
    if ((a.Y()>p.Y())==(b.Y()>p.Y())) continue;
    const double cross=a.X()+(p.Y()-a.Y())*(b.X()-a.X())/(b.Y()-a.Y());
    if(cross>p.X()) winding+=b.Y()>a.Y()?1:-1;
  }
  if(winding!=0 && winding!=1) throw std::runtime_error("mesh section does not enclose a simple region");
  return winding==1;
}

bool grade(const TopoDS_Shape& result, std::istream& gold)
{
  if(result.IsNull()) return false;
  double expected=0.,drift=0.;
  if(!(gold>>expected>>drift) || expected<=0. || drift>=expected*2.5e-5) return false;
  TopExp_Explorer it(result,TopAbs_FACE);
  if(!it.More()) return false;
  const auto face=TopoDS::Face(it.Current());
  it.Next();
  BRepAdaptor_Surface surface(face);
  if(it.More() || surface.GetType()!=GeomAbs_Plane ||
     std::abs(surface.Plane().Axis().Direction().Z())<1.-1e-12 ||
     std::abs(surface.Plane().Location().Z())>1e-6) return false;
  GProp_GProps data;
  BRepGProp::SurfaceProperties(result,data,1e-8);
  int found=0,inside=0,outside=0,wrong=0;
  double x,y;
  int expectedIn;
  while(gold>>x>>y>>expectedIn)
  {
    BRepClass_FaceClassifier cls(face,gp_Pnt(x,y,0),1e-6);
    ++found;
    (expectedIn?inside:outside)++;
    if(cls.State()!=(expectedIn?TopAbs_IN:TopAbs_OUT)) ++wrong;
  }
  const bool pass=BRepCheck_Analyzer(result).IsValid() &&
                  std::abs(data.Mass()-expected)+2*drift<=expected*1e-4 &&
                  found>=120 && inside>25 && outside>25 && wrong==0;
  std::cout << (pass?"PASS":"FAIL") << " area=" << data.Mass() << " expected=" << expected
            << " drift=" << drift << " witness_inside=" << inside << " witness_outside=" << outside
            << " witness_mismatches=" << wrong << '\n';
  return pass;
}

int main(int argc,char** argv)
{
  if(argc!=2) return 2;
  auto solid=readSolid();
  if(solid.IsNull()) return 3;
  std::cout << std::setprecision(17);
  const std::string mode=argv[1];
  if(mode=="mesh")
  {
    std::vector<Segment> finest;
    double coarse=0.,previous=0.,value=0.;
    for(double deflection:{8.,4.,2.,1.,0.5,0.25,0.125,0.0625})
    {
      BRepTools::Clean(solid);
      BRepMesh_IncrementalMesh mesh(solid,deflection,false,0.12,false);
      if(!mesh.IsDone()) return 3;
      auto lines=cutMesh(solid,0.);
      previous=coarse;coarse=value;value=sectionArea(lines);
      std::cout << "MESH " << deflection << ' ' << lines.size() << ' ' << value << '\n';
      if(deflection==0.0625) finest=std::move(lines);
    }
    const double drift=std::max(std::abs(value-coarse),std::abs(coarse-previous));
    if(value<=0. || drift>=value*2.5e-5 || finest.empty()) return 4;
    double xmin=std::numeric_limits<double>::max(),xmax=-xmin,ymin=xmin,ymax=-xmin;
    for(const auto& e:finest)
      for(const auto& p:{e.start,e.end})
      {
        xmin=std::min(xmin,p.X());xmax=std::max(xmax,p.X());
        ymin=std::min(ymin,p.Y());ymax=std::max(ymax,p.Y());
      }
    std::ofstream f("slice-gold.txt");
    f<<std::setprecision(17)<<value<<' '<<drift<<'\n';
    for(int i=-1;i<=34;++i)
      for(int j=-1;j<=16;++j)
      {
        gp_Pnt p(xmin+(xmax-xmin)*(i+.5)/34.,ymin+(ymax-ymin)*(j+.5)/16.,0);
        if(std::any_of(finest.begin(),finest.end(),[&](const Segment& e){return distance(p,e)<16.;})) continue;
        f<<p.X()<<' '<<p.Y()<<' '<<contains(finest,p)<<'\n';
      }
    return f.good()?0:5;
  }
  if(mode=="controls")
  {
    std::ifstream area("slice-gold.txt");
    double expected;
    if(!(area>>expected)) return 4;
    gp_Pln xy(gp_Ax3(gp_Pnt(0,0,0),gp_Dir(0,0,1),gp_Dir(1,0,0)));
    // Equal-area but wrong location and a coherent but incomplete region both satisfy a relative-area-only comparison.
    for (const auto& control:std::vector<std::pair<const char*,double>>{{"equal_area_displaced",1.},{"incomplete_rectangle",0.22}})
    {
      const auto face=BRepBuilderAPI_MakeFace(xy,1e6,1e6+10000.,1e6,1e6+expected*control.second/10000.).Face();
      std::cout << control.first << ' ';
      std::ifstream gold("slice-gold.txt");
      if(grade(face,gold)) return 5;
    }
    return 0;
  }
  char* end=nullptr;
  const double degrees=std::strtod(argv[1],&end);
  if(*end) return 2;
  const double a=degrees*std::acos(-1.)/180.;
  const gp_Pln plane(gp_Ax3(gp_Pnt(),gp_Dir(0,0,1),gp_Dir(std::cos(a),std::sin(a),0)));
  BRepAlgoAPI_Common common(BRepBuilderAPI_MakeFace(plane).Face(),solid);
  if(!common.IsDone() || common.HasErrors() || common.Shape().IsNull()) return 3;
  BRepTools::Write(common.Shape(),"section.brep");
  std::ifstream gold("slice-gold.txt");
  std::cout << "ANGLE " << degrees << " WARN " << common.HasWarnings() << ' ';
  return grade(common.Shape(),gold) && !common.HasWarnings()?0:1;
}
