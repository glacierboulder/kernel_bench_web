// Estimate the change in section area from two independent mesh resolutions.
// Use the previously converged central-plane area as the fixed anchor.
#define main old_slice_main
#include "slice.cpp"
#undef main
#include <BRepClass3d_SolidClassifier.hxx>

int main()
{
  const auto solid=readSolid();
  if(solid.IsNull()) return 2;
  std::cout<<std::setprecision(17);
  std::vector<std::vector<double>> deltas;
  for(double deflection:{1.,0.5})
  {
    BRepTools::Clean(solid);
    BRepMesh_IncrementalMesh mesh(solid,deflection,false,0.12,false);
    if(!mesh.IsDone()) return 3;
    const double atZero=sectionArea(cutMesh(solid,0.));
    const double minus=sectionArea(cutMesh(solid,-0.001))-atZero;
    const double plus=sectionArea(cutMesh(solid,0.001))-atZero;
    deltas.push_back({minus,plus});
    std::cout<<"DELTA "<<deflection<<' '<<atZero<<' '<<minus<<' '<<plus<<std::endl;
  }
  TopExp_Explorer it(solid,TopAbs_SOLID);
  if(!it.More()) return 4;
  BRepClass3d_SolidClassifier classifier(it.Current());
  it.Next();
  if(it.More()) return 5;
  for(int sign:{-1,1})
  {
    const int index=sign>0?1:0;
    const double z=sign*0.001;
    std::ifstream current("center-gold.txt");
    double area,uncertainty;
    if(!(current>>area>>uncertainty)) return 6;
    area+=deltas[1][index];
    uncertainty+=std::abs(deltas[1][index]-deltas[0][index]);
    std::ofstream result(sign>0?"plus-gold.txt":"minus-gold.txt");
    result<<std::setprecision(17)<<area<<' '<<uncertainty<<' '<<z<<'\n';
    double x,y;
    int expected,n=0;
    while(current>>x>>y>>expected)
    {
      classifier.Perform(gp_Pnt(x,y,z),1e-6);
      if(classifier.State()!=(expected?TopAbs_IN:TopAbs_OUT))
        return 7;
      result<<x<<' '<<y<<' '<<expected<<'\n';
      ++n;
    }
    if(n!=642 || !result.good()) return 8;
    std::cout<<"GOLD "<<z<<' '<<area<<' '<<uncertainty<<' '<<n<<std::endl;
  }
}
