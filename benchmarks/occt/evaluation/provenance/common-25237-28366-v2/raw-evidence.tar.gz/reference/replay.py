"""Replay registered C++ cases and assessor-only analytical/mesh checks on the locked kernels."""
from concurrent.futures import ThreadPoolExecutor
from pathlib import Path
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parent
BASE=Path('/var/tmp/m25542-positive-reference-20261119/current')
IMAGE=Path('/var/tmp/cad-boolean-screen30-20261118/image')
TASKS=('25237','28366')
LIBS=['TKBO','TKPrim','TKMesh','TKGeomAlgo','TKGeomBase','TKBRep','TKG3d','TKG2d','TKTopAlgo','TKMath','TKernel']
LIBDIR='/workspace/build/lin64/gcc/lib'

def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def read(p):
    return json.loads(p.read_bytes())
def save(p,v):
    p.write_text(json.dumps(v,indent=2)+'\n')

def sandbox(rt, work, args, filename, seconds=180, mounts=(), cpus='2-5'):
    call=['/usr/bin/taskset','-c',cpus,'/usr/bin/bwrap','--unshare-all','--die-with-parent','--ro-bind',str(IMAGE),'/',
          '--proc','/proc','--dev','/dev','--tmpfs','/tmp','--bind',str(work),'/workspace',
          '--ro-bind',str((rt/'source').resolve()),'/workspace/source','--ro-bind',str(rt/'build'),'/workspace/build',
          '--chdir','/workspace','--setenv','HOME','/tmp','--setenv','PATH','/usr/bin:/bin',
          '--setenv','LD_LIBRARY_PATH',LIBDIR]
    for src,dst in mounts:
        call+=['--ro-bind',str(src),dst]
    with filename.open('wb') as log:
        return subprocess.run(call+args,stdout=log,stderr=subprocess.STDOUT,timeout=seconds).returncode

def compile_case(rt,work,source,exe):
    code=sandbox(rt,work,['/usr/bin/g++-13','-O2','-std=c++17','-I/workspace/build/include/opencascade',
                        source,'-L'+LIBDIR,*['-l'+lib for lib in LIBS],'-o',exe],work/'compile.log')
    if code!=0:
        raise RuntimeError((work/'compile.log').read_text()[-3000:])

def run_registered(rt,n,cp,out):
    case=ROOT/'locked'/n
    out.mkdir(parents=True,exist_ok=True)
    for source in case.glob('*.brep'):
        shutil.copyfile(source,out/source.name)
    shutil.copyfile(case/Path(cp['case']).name,out/'case.cpp')
    compile_case(rt,out,'case.cpp','registered')
    code=sandbox(rt,out,['./registered'],out/'run.log')
    text=(out/'run.log').read_text()
    return dict(id=cp['id'],status='PASS' if code==0 and all(x in text for x in cp['runner_options']['stdout_contains']) else 'FAIL',
                exit=code,case_sha256=sha(out/'case.cpp'),output=text)

def run_geometry(rt,n,out):
    out.mkdir(parents=True,exist_ok=True)
    name='arc' if n=='25237' else 'slice'
    for source in (ROOT/'locked'/n).glob('*.brep'):
        shutil.copyfile(source,out/source.name)
    shutil.copyfile(ROOT/'geometry'/(name+'.cpp'),out/'geometry.cpp')
    compile_case(rt,out,'geometry.cpp','geometry')
    rows=[]
    placements=('original','translation','rotation') if n=='25237' else ('0','37','90')
    if n=='28366':
        shutil.copyfile(ROOT/'gold'/'slice-gold.txt',out/'slice-gold.txt')
    for placement in placements:
        log=out/(placement+'.log')
        code=sandbox(rt,out,['./geometry',placement],log,180)
        if code not in (0,1):raise RuntimeError(log.read_text()[-1500:])
        for shape in list(out.glob('arc-*.brep'))+list(out.glob('section.brep')):
            shape.replace(out/(placement+'-'+shape.name))
        rows.append(dict(placement=placement,status='PASS' if code==0 else 'FAIL',exit=code,output=log.read_text()))
    return rows

def run_gold():
    out=ROOT/'gold'
    out.mkdir(exist_ok=True)
    shutil.copyfile(ROOT/'geometry'/'slice.cpp',out/'slice.cpp')
    shutil.copyfile(ROOT/'locked/28366/fuselage-derived.brep',out/'fuselage-derived.brep')
    compile_case(BASE,out,'slice.cpp','slice')
    log=out/'mesh.log'
    code=sandbox(BASE,out,['./slice','mesh'],log,600)
    if code!=0:
        raise RuntimeError('mesh reference exit '+str(code)+' '+log.read_text()[-3500:])
    log=out/'slice-controls.log'
    assert sandbox(BASE,out,['./slice','controls'],log)==0, log.read_text()
    shutil.copyfile(ROOT/'geometry'/'arc.cpp',out/'arc.cpp')
    shutil.copyfile(ROOT/'locked/25237/bug25237_b26.brep',out/'bug25237_b26.brep')
    shutil.copyfile(ROOT/'locked/25237/bug25237_b5.brep',out/'bug25237_b5.brep')
    compile_case(BASE,out,'arc.cpp','arc')
    log=out/'arc-controls.log'
    assert sandbox(BASE,out,['./arc','controls'],log)==0, log.read_text()

def qualify(n,side):
    result=ROOT/'qualification'/n/side
    rt=BASE if side=='B' else ROOT/'reference'/n
    suite=read(ROOT/'locked'/n/'suite.json')
    records=[run_registered(rt,n,cp,result/cp['id']) for cp in suite['checkpoints'] if cp['required']]
    independent=run_geometry(rt,n,result/'geometry')
    save(result/'result.json',dict(native=records,independent=independent))
    print(n,side,[r['status'] for r in records],[r['status'] for r in independent],flush=True)

if __name__=='__main__':
    if sys.argv[1]=='gold':
        run_gold()
    else:
        with ThreadPoolExecutor(max_workers=4) as pool:
            list(pool.map(lambda k:qualify(*k),[(n,s) for n in TASKS for s in ('B','F')]))
