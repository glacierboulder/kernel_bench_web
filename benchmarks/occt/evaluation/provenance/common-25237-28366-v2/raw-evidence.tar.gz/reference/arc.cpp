// Verify the expected common arc from the precise input circle independently of Boolean selection.
#include <BRepAdaptor_Curve.hxx>
#include <BRepAlgoAPI_Common.hxx>
#include <BRepBuilderAPI_MakeEdge.hxx>
#include <BRepTools.hxx>
#include <BRep_Builder.hxx>
#include <BRepCheck_Analyzer.hxx>
#include <BRepGProp.hxx>
#include <GProp_GProps.hxx>
#include <TopExp_Explorer.hxx>
#include <TopoDS.hxx>
#include <gp_Ax1.hxx>
#include <gp_Trsf.hxx>
#include <fstream>
#include <iostream>
#include <iomanip>
#include <string>
#include <algorithm>
#include <cmath>

TopoDS_Shape read(const char* file)
{
  std::ifstream stream(file);
  std::string header;
  std::getline(stream, header);
  TopoDS_Shape shape;
  BRepTools::Read(shape, stream, BRep_Builder());
  return shape;
}

bool grade(const TopoDS_Shape& shape, const TopoDS_Edge& exact)
{
  if (shape.IsNull()) return false;
  BRepAdaptor_Curve reference(exact);
  const auto circle = reference.Circle();
  const double a = reference.FirstParameter(), b = reference.LastParameter();
  const double expected = circle.Radius() * (b - a);
  TopExp_Explorer edges(shape, TopAbs_EDGE);
  if (!edges.More()) return false;
  const auto edge = TopoDS::Edge(edges.Current());
  edges.Next();
  if (edges.More()) return false;
  BRepAdaptor_Curve actual(edge);
  const double lo = actual.FirstParameter(), hi = actual.LastParameter();
  const auto start = reference.Value(a), end = reference.Value(b);
  const auto x = actual.Value(lo), y = actual.Value(hi);
  // Calibrated below the sum of the two vertex tolerances for the precise edge.
  constexpr double spatial = 1.6e-5;
  const double endpoint = std::min(std::max(start.Distance(x),end.Distance(y)),
                                   std::max(start.Distance(y),end.Distance(x)));
  double max_error = 0.;
  for (int i = 0; i <= 64; ++i)
  {
    const gp_Vec travel(circle.Location(),actual.Value(lo+(hi-lo)*i/64.));
    const double dx = travel.Dot(gp_Vec(circle.XAxis().Direction()));
    const double dy = travel.Dot(gp_Vec(circle.YAxis().Direction()));
    const double z = travel.Dot(gp_Vec(circle.Axis().Direction()));
    double angle = std::atan2(dy,dx);
    angle += std::round(((a+b)*0.5-angle)/(2*std::acos(-1.)))*2*std::acos(-1.);
    max_error = std::max({max_error,std::abs(z), std::abs(std::hypot(dx,dy)-circle.Radius()),
                          circle.Radius()*std::max({a-angle,angle-b,0.})});
  }
  GProp_GProps props;
  BRepGProp::LinearProperties(shape,props);
  const bool pass = BRepCheck_Analyzer(shape).IsValid() && endpoint <= spatial &&
                    max_error <= spatial && std::abs(props.Mass()-expected) < 1e-6;
  std::cout << (pass?"PASS":"FAIL") << " length=" << props.Mass() << " expected=" << expected
            << " endpoint_error=" << endpoint << " support_error=" << max_error << '\n';
  return pass;
}

int main(int argc,char** argv)
{
  if (argc!=2) return 2;
  const auto circle=TopoDS::Edge(read("bug25237_b26.brep"));
  const auto other=read("bug25237_b5.brep");
  BRepAdaptor_Curve ref(circle);
  std::cout << std::setprecision(17);
  if (std::string(argv[1])=="controls")
  {
    const auto c=ref.Circle();
    const double a=ref.FirstParameter(),b=ref.LastParameter();
    gp_Trsf shift;
    shift.SetTranslation(gp_Vec(0,0,1));
    std::cout << "exact ";
    if (!grade(circle,circle)) return 4;
    std::cout << "equal_length_shifted ";
    if (grade(circle.Moved(TopLoc_Location(shift)),circle)) return 5;
    std::cout << "equal_length_adjacent ";
    if (grade(BRepBuilderAPI_MakeEdge(c,b,2*b-a).Edge(),circle)) return 6;
    std::cout << "trimmed ";
    if (grade(BRepBuilderAPI_MakeEdge(c,a,(a+b)*.5).Edge(),circle)) return 7;
    return 0;
  }
  const std::string placement(argv[1]);
  gp_Trsf transform;
  if(placement=="translation") transform.SetTranslation(gp_Vec(17,-13,9));
  else if(placement=="rotation") transform.SetRotation(gp_Ax1(gp_Pnt(),gp_Dir(0,0,1)),37*std::acos(-1.)/180.);
  else if(placement!="original") return 2;
  const auto first=TopoDS::Edge(circle.Moved(TopLoc_Location(transform)));
  const auto second=other.Moved(TopLoc_Location(transform));
  bool pass=true;
  for(int swap=0;swap<2;++swap)
  {
    BRepAlgoAPI_Common operation(swap?second:first,swap?first:second);
    if(!operation.IsDone() || operation.HasErrors()) return 3;
    std::cout << placement << " swap=" << swap << ' ';
    if(!grade(operation.Shape(),first)) pass=false;
    BRepTools::Write(operation.Shape(), ("arc-"+std::to_string(swap)+".brep").c_str());
  }
  return pass?0:1;
}
