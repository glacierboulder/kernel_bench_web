#!/bin/bash
set -eu
root=/var/tmp/cad-common-fresh15-20261119
base=/var/tmp/m25542-positive-reference-20261119/current
image=/var/tmp/cad-boolean-screen30-20261118/image
prepare() {
  n=$1
  fresh="$root/reference/$n"
  mkdir -p "$fresh"
  cp -a --reflink=auto "$base/source/" "$fresh/source"
  cp -a --reflink=auto "$base/build" "$fresh/build"
  git -C "$fresh/source" apply --check "$root/locked/$n/reference.patch"
  git -C "$fresh/source" apply "$root/locked/$n/reference.patch"
  taskset -c "$2" bwrap --unshare-all --die-with-parent --ro-bind "$image" / --dev /dev --proc /proc --tmpfs /tmp \
    --tmpfs /workspace --ro-bind "$fresh/source" /workspace/source --bind "$fresh/build" /workspace/build \
    --chdir /workspace/build --setenv HOME /tmp --setenv PATH /usr/bin:/bin \
    cmake --build /workspace/build --parallel 2 --target TKBO >"$fresh/build.log" 2>&1
}
prepare 25237 2,3 &
p1=$!
prepare 28366 4,5 &
p2=$!
status=0
wait "$p1" || status=1
wait "$p2" || status=1
exit "$status"
