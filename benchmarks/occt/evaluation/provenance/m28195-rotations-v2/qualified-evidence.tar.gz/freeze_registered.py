"""Freeze the registered alternate suite against the verified baseline cache."""
import json
import os
from pathlib import Path
from backend.catalog import public_task, validate_bundle
from backend.freeze import freeze_catalog_task, verify_snapshot

root = Path(__file__).resolve().parent
bundle = validate_bundle(os.environ['BENCHMARK_ROOT'])
group = bundle['groups']['occt-single20-28195', '1']
suite = {'id': 'occt-single20-28195-checks', 'version': '2'}
assert group['evaluation_suite'] == dict(suite, version='1')
assert bundle['suites'][suite['id'], '2']['checkpoints'][:4] == bundle['suites'][suite['id'], '1']['checkpoints']
manifest = freeze_catalog_task(public_task(bundle, group), root/'final', suite_override=suite)
verify_snapshot(root/'final/benchmark-snapshot')
print(json.dumps(manifest, indent=2))
