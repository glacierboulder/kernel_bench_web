set ::tcl_library /home/lzy/cad-bench-experiment/runtime/py311/lib/tcl8.6
source [file join $::tcl_library init.tcl]
source /control/cases/bundle/evaluation/cases/single20/occt-28195/2/rotated_common.tcl
if {[catch {
    set pose $::env(POSE)
    switch $pose {
        axis31 {set rotation {100 20 -10 1 2 3 31}; set gold_volume 172189705.92920938}
        z90    {set rotation {0 0 0 0 0 1 90};     set gold_volume 172189705.92920932}
        default {error "unknown pose"}
    }
    ::m28195::load_operands $rotation
    switch $::env(CONTROL) {
        gold - shifted {
            restore /gold.brep result
            trotate result {*}$rotation
            if {$::env(CONTROL) eq "shifted"} {ttranslate result 1000000 1000000 1000000}
        }
        empty {compound result}
        input_only {copy input_2 result}
        default {error "unknown control"}
    }
    ::m28195::check_geometry $pose $gold_volume
} message]} {puts stderr "CONTROL_ERROR $::errorInfo"}
