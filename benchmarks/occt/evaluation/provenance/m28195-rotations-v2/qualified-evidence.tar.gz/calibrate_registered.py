"""Exercise the registered observer on transported gold and adversarial shapes using F."""
from concurrent.futures import ThreadPoolExecutor
import importlib.util
import os
from queue import SimpleQueue
import sys
sys.dont_write_bytecode = True
from runtime import ROOT, PROTOCOL, bench, rt, sha, write
from itertools import product

snapshot=ROOT/'final/benchmark-snapshot'
bench.verify_snapshot(snapshot)
supervisor=snapshot/'supervisor'
contract=bench.load(supervisor/'evaluator_assets/unified_runtime/contract.json')
module_path=supervisor/'evaluator_assets/unified_runtime/assertion_oracle.py'
spec=importlib.util.spec_from_file_location('validator',module_path)
validator=importlib.util.module_from_spec(spec)
spec.loader.exec_module(validator)
gold=ROOT/'assets/canonical-reference.brep'
assert sha(gold)==PROTOCOL['assets_sha256']['canonical-reference.brep']
def measure(job):
    pose,mode=job
    folder=ROOT/'final-calibration'/pose/mode
    folder.mkdir(parents=True)
    r=rt('F')
    mounts=[(r/'source','/workspace/source',False),(r/'build','/workspace/build',False),
            (supervisor,'/control',False),(ROOT/'controls','/checks',False),(gold,'/gold.brep',False)]
    code=bench.invoke(folder,['/workspace/build/lin64/clang/bin/DRAWEXE','-b','-f','/checks/measure.tcl'],
                      folder/'draw.log',120,mounts,extra=dict(POSE=pose,CONTROL=mode))
    output=(folder/'draw.log').read_text()
    key='28195-'+('neighborhood_axis31' if pose=='axis31' else 'regression_z90')
    route=dict(contract['checkpoints'][key])
    route['expected_assertion_ids']=[x for x in route['expected_assertion_ids'] if x!='operation_completed']
    result=validator.validate_base_result(dict(return_code=code,timed_out=code==124,stdout_tail=output,
                  tcl_error_detected='CONTROL_ERROR' in output,passed=code==0),route)
    state=validator.completed_failure_status(result)
    failures=[e['id'] for e in result['observed_assertion_events'] if e['status']=='FAIL']
    assert state == ('geometry_pass' if mode=='gold' else 'geometry_fail'), (pose,mode,state,output[-1100:])
    assert not any(f in failures for f in ('input_1_qualified','input_2_qualified','operand_membership'))
    if mode=='input_only':
        assert 'volume' in failures and 'exclusion_membership' in failures and 'grid_membership' not in failures
    if mode=='shifted':
        assert 'grid_membership' in failures and 'volume' not in failures
    write(folder/'result.json',dict(pose=pose,mode=mode,status=state,failed_assertions=failures,log_sha256=sha(folder/'draw.log')))
    return pose, mode, state
cpus=sorted(os.sched_getaffinity(0))
workers=min(3,max(1,len(cpus)//2))
lanes=SimpleQueue()
for i in range(workers):lanes.put(cpus[2*i:2*i+2])
with ThreadPoolExecutor(max_workers=workers,initializer=lambda:os.sched_setaffinity(0,lanes.get())) as pool:
    for row in pool.map(measure,product(('axis31','z90'),('gold','empty','input_only','shifted'))):print(*row)
