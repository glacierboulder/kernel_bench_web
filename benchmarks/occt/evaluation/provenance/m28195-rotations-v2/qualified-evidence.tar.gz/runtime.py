"""Prepare clean historical and patched runtimes for this diagnostic on ws01."""
import hashlib
import json
import os
from pathlib import Path
import sys
from concurrent.futures import ThreadPoolExecutor

ROOT=Path(__file__).resolve().parent
STUDY=Path('/home/lzy/cad-bench-experiment')
BASE=Path('/var/tmp/cad-bench-lzy-single20-20261102/jobs/frozen-replay-08/occt-single20-28195')
PROTOCOL=json.loads((ROOT/'protocol.json').read_bytes())
def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()
def write(p,obj):
    p.write_text(json.dumps(obj,indent=2)+'\n')
helper=STUDY/'common-empirical-third-20261120'/'registered.py'
assert sha(helper)==PROTOCOL['registered_helper_sha256']
sys.path.insert(0,str(helper.parent))
import registered as bench

def rt(label):
    if label in ('B','F'):
        return BASE/label.lower()/'runtime'
    return ROOT/'builds'/label/'clean'

def prepare_origin(label):
    spec=PROTOCOL['baseline' if label=='B' else 'reference']
    runtime=rt(label)
    manifest=runtime.parent/'runtime-binaries.json'
    assert sha(manifest)==spec['runtime_manifest']
    for name,expected in bench.load(manifest).items():
        assert sha(runtime/'build'/name)==expected,(label,name)
    assert bench.tree_sha256(runtime/'source')==spec['tree']
    return dict(**spec,binaries_verified=len(bench.load(manifest)))

def build(label):
    folder=ROOT/'builds'/label
    folder.mkdir(parents=True)
    clean=rt(label)
    clean.mkdir()
    for name in ('source','build'):
        bench.copy(rt('B')/name,clean/name)
    assert bench.tree_sha256(clean/'source')==PROTOCOL['baseline']['tree']
    patch=ROOT/'assets'/(label+'.diff')
    assert sha(patch)==PROTOCOL['rounds'][label]['sha256']
    bench.apply_patch(clean/'source',str(patch))
    tool=BASE/'b/benchmark-snapshot/tools'
    assert sha(tool/'build.sh')==bench.load(STUDY/'common-empirical-third-20261120/protocol.json')['tasks']['28195']['tools']['build.sh']
    code=bench.invoke(clean,['bash','/tools/build.sh','/workspace/source','/workspace/build'],
                      folder/'build.log',1800,[(tool,'/tools',False)])
    if code:raise ValueError((label,code))
    baseline=bench.load(rt('B').parent/'runtime-binaries.json')
    actual={n:sha(clean/'build'/n) for n in baseline}
    changed=[n for n in baseline if actual[n]!=baseline[n]]
    assert any('TKBO' in n for n in changed),changed
    write(folder/'binaries.json',actual)
    result=dict(base=PROTOCOL['baseline']['commit'],patch=sha(patch),source_tree=bench.tree_sha256(clean/'source'),
                binary_manifest=sha(folder/'binaries.json'),changed=changed,build_exit=code)
    write(folder/'receipt.json',result)
    return result

if __name__=='__main__':
    for filename,expected in PROTOCOL['assets_sha256'].items():
        assert sha(ROOT/'assets'/filename)==expected
    with ThreadPoolExecutor(max_workers=2) as pool:
        origins=dict(zip(('B','F'),pool.map(prepare_origin,('B','F'))))
    write(ROOT/'verified-origins.json',origins)
    with ThreadPoolExecutor(max_workers=2) as pool:
        builds=dict(zip(PROTOCOL['rounds'],pool.map(build,PROTOCOL['rounds'])))
    print('Verified',list(origins),'built',list(builds))
