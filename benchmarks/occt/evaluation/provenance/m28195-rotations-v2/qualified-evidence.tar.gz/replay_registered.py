"""Use checked source/build identities, then exercise all six frozen checkpoints by name."""
from concurrent.futures import ThreadPoolExecutor
from runtime import ROOT, bench, rt, PROTOCOL, sha
import sys
import os
from queue import SimpleQueue

snapshot = ROOT/'final/benchmark-snapshot'
supervisor = snapshot/'supervisor'
bench.verify_snapshot(snapshot)
def execute(label):
    folder = ROOT/'final-results'/label
    folder.mkdir(parents=True)
    runtime = rt(label)
    if label in ('B','F'):
        meta = bench.load(ROOT/'verified-origins.json')[label]
        assert bench.tree_sha256(runtime/'source') == meta['tree']
        binaries = runtime.parent/'runtime-binaries.json'
        assert sha(binaries) == meta['runtime_manifest']
    else:
        meta = bench.load(runtime.parent/'receipt.json')
        assert meta['patch'] == PROTOCOL['rounds'][label]['sha256'] and meta['build_exit'] == 0
        assert bench.tree_sha256(runtime/'source') == meta['source_tree']
        binaries = runtime.parent/'binaries.json'
        assert sha(binaries) == meta['binary_manifest']
    for path,digest in bench.load(binaries).items():
        assert sha(runtime/'build'/path) == digest
    mounts = [(supervisor,'/control',False),(snapshot/'suite.json','/suite.json',False),
              (ROOT/'dispatch.py','/dispatch.py',False),
              (runtime/'source','/occt-source',False),(runtime/'build','/occt-build',False)]
    code = bench.invoke(folder,[sys.executable,'/dispatch.py'],folder/'dispatch.log',700,mounts,
                        extra={'CASROOT':'/occt-source','BENCH_FROZEN_CASE_ROOT':'/control/cases/bundle'})
    print(label,code,flush=True)
    if code: raise RuntimeError((label,(folder/'dispatch.log').read_text()[-2000:]))
cpus = sorted(os.sched_getaffinity(0))
lanes = SimpleQueue()
# The sandbox keeps the first two allowed CPUs, so give each worker its own pair.
workers = min(5, max(1, len(cpus) // 2))
for i in range(workers):
    lanes.put(cpus[-2*workers:][2*i:2*i+2])
with ThreadPoolExecutor(max_workers=workers, initializer=lambda: os.sched_setaffinity(0, lanes.get())) as pool:
    list(pool.map(execute, ('B','F','round1','round2','round3')))
