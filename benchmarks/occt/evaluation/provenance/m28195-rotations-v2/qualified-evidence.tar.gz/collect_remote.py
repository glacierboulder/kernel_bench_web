"""Archive scorer outputs only, without exporting OCCT working trees."""
import tarfile
from pathlib import Path
from runtime import ROOT, bench
bench.verify_snapshot(ROOT/'final/benchmark-snapshot')
roles=('B','F','round1','round2','round3')
cpids=[c['id'] for c in bench.load(ROOT/'final/benchmark-snapshot/suite.json')['checkpoints']]
def files():
    for key in ('assets/canonical-reference.brep','qualified-results/F/28195-neighborhood_axis31.json','final-material-verification.json','verify_final.py','collect_remote.py','catalog-tests.log','final-freeze.json','final-calibration.log','final-replay.log',
                'verified-origins.json','rebuild.log','freeze_registered.py','calibrate_registered.py',
                'replay_registered.py','dispatch.py','controls/measure.tcl','runtime.py','protocol.json',
                'final/benchmark-snapshot/suite.json','final/benchmark-snapshot/supervisor/evaluator_assets/unified_runtime/contract.json'):
        yield key
    for label in roles:
        for cp in cpids:
            yield f'final-results/{label}/{cp}.json'
        yield f'final-results/{label}/dispatch.log'
    for label in roles[2:]:
        for name in ('receipt.json','binaries.json','build.log'):
            yield f'builds/{label}/{name}'
        yield f'assets/{label}.diff'
    for pose in ('axis31','z90'):
        for mode in ('gold','empty','input_only','shifted'):
            for name in ('draw.log','result.json'):
                yield f'final-calibration/{pose}/{mode}/{name}'
with tarfile.open(ROOT/'qualified-evidence.tar.gz','w:gz') as tar:
    for name in files():
        path=ROOT/name
        assert path.is_file() and path.stat().st_size, path
        tar.add(path,arcname=name,recursive=False)
