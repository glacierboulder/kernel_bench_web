"""Run the production checkpoint dispatcher on one already verified build inside bwrap."""
import json
import sys
from pathlib import Path
sys.path.insert(0, '/control')
from suite_driver import _execute, checkpoint_status

suite = json.loads(Path('/suite.json').read_bytes())
assert suite['version'] == '2' and len(suite['checkpoints']) == 6
for cp in suite['checkpoints']:
    result = _execute(cp, case_root=Path('/control/cases/bundle'), build=Path('/occt-build'),
                      source=Path('/occt-source'), work=Path('/workspace'),
                      draw_runner=Path('/control/legacy/scripts/run_draw_case.py'))
    row = {'id': cp['id'], 'status': checkpoint_status(result), **result}
    Path('/workspace', cp['id']+'.json').write_text(json.dumps(row, indent=2)+'\n')
    print(cp['id'], row['status'], flush=True)
    assert row['status'] in ('passed','failed'), result
    detail = result['result']
    assert detail['checkpoint_id'] == cp['id'] and detail['oracle_ran']
