"""Verify that the frozen runtime loads only sources from the clean registered suite."""
import hashlib
import json
import os
from pathlib import Path
from backend.freeze import verify_snapshot
from backend.catalog import validate_bundle
from backend.occt_runtime import configuration
root=Path(__file__).resolve().parent
snap=root/'final/benchmark-snapshot'
verify_snapshot(snap)
s=json.loads((snap/'suite.json').read_bytes())
b=validate_bundle(os.environ['BENCHMARK_ROOT'])
assert s==b['suites'][s['id'], '2']
files=[cp['case'] for cp in s['checkpoints']]+s['support_files']
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
digests={f:sha(b['root']/f) for f in files}
assert all(sha(snap/'supervisor/cases/bundle'/f)==h for f,h in digests.items())
assert not any(p.name.startswith('._') for p in snap.rglob('*'))
assets=snap/'supervisor/evaluator_assets/unified_runtime'
contract=json.loads((assets/'contract.json').read_bytes())
assert contract==configuration(b['root'],s)
entry={'executed_snapshot':json.loads((snap/'snapshot.json').read_bytes())['snapshot_sha256'],
       'scoring_assets_byte_identical':True,'files':digests,'contract_sha256':sha(assets/'contract.json')}
(root/'final-material-verification.json').write_text(json.dumps(entry,indent=2)+'\n')
